'use client';

import { useState } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import type { LucideIcon } from 'lucide-react';
import { ArrowLeft, Users, Briefcase, CalendarCheck, TrendingUp, DollarSign, Shield, CreditCard, ChevronRight, QrCode, UserPlus, BarChart3, CheckCircle, XCircle, Clock, Wind, Zap, Droplets, Camera, Search } from 'lucide-react';
import { STATUS_CONFIG } from '@/lib/services-data';
import { MOCK_BOOKINGS, MOCK_UPI_PAYMENTS, MOCK_TECHNICIANS, PAYMENT_STATUS_CONFIG } from '@/lib/mock-data';

type AdminTab = 'overview' | 'bookings' | 'payments' | 'technicians';

const TAB_ITEMS: { key: AdminTab; label: string; icon: LucideIcon }[] = [
  { key: 'overview', label: 'Overview', icon: BarChart3 },
  { key: 'bookings', label: 'Bookings', icon: CalendarCheck },
  { key: 'payments', label: 'UPI Payments', icon: CreditCard },
  { key: 'technicians', label: 'Technicians', icon: Users },
];

const BOOKING_ICONS: Record<string, LucideIcon> = { 'AC Service': Wind, 'CCTV Installation': Camera, Plumbing: Droplets, Electrician: Zap };

export default function AdminPage() {
  const [tab, setTab] = useState<AdminTab>('overview');
  const [search, setSearch] = useState('');
  const [bookingFilter, setBookingFilter] = useState<string>('all');

  const activeTechnicians = MOCK_TECHNICIANS.filter(t => t.status === 'active').length;
  const totalEarnings = MOCK_UPI_PAYMENTS.filter(p => p.status === 'success').reduce((a, p) => a + p.amount, 0);
  const pendingBookings = MOCK_BOOKINGS.filter(b => b.status === 'pending').length;

  const filteredBookings = MOCK_BOOKINGS.filter(b => {
    const matchSearch = b.customerName.toLowerCase().includes(search.toLowerCase()) || b.serviceName.toLowerCase().includes(search.toLowerCase());
    const matchFilter = bookingFilter === 'all' || b.status === bookingFilter;
    return matchSearch && matchFilter;
  });

  const filteredPayments = MOCK_UPI_PAYMENTS.filter(p =>
    p.customerName.toLowerCase().includes(search.toLowerCase()) ||
    p.transactionId.toLowerCase().includes(search.toLowerCase()) ||
    p.upiId.toLowerCase().includes(search.toLowerCase())
  );

  const handleBookingStatus = (bookingId: string, newStatus: string) => {
    // In production this would update Supabase
    console.log(`Booking ${bookingId} -> ${newStatus}`);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }} className="min-h-screen bg-[#070707] pb-10">
      {/* Header */}
      <div className="sticky top-0 z-40 glass-strong border-b border-white/[0.04]">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/" className="p-1.5 rounded-xl hover:bg-white/5"><ArrowLeft size={18} className="text-white/60" /></Link>
            <div>
              <h1 className="text-base font-bold text-white">Admin Dashboard</h1>
              <p className="text-[9px] text-orange-500/70 font-bold tracking-wider uppercase">VATTAM Control</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 bg-red-500/10 border border-red-500/20 px-2.5 py-1 rounded-xl">
            <Shield size={11} className="text-red-400" />
            <span className="text-[10px] text-red-400 font-bold">ADMIN</span>
          </div>
        </div>
        {/* Tabs */}
        <div className="max-w-2xl mx-auto px-4 pb-3">
          <div className="flex gap-1 glass rounded-2xl p-1">
            {TAB_ITEMS.map(({ key, label, icon: Icon }) => (
              <button key={key} onClick={() => setTab(key)}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs font-bold transition-all duration-300 ${tab === key ? 'bg-gradient-to-r from-orange-500 to-orange-600 text-black' : 'text-white/30 hover:text-white/50'}`}>
                <Icon size={12} />
                <span className="hidden sm:block">{label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 pt-4">
        {/* OVERVIEW TAB */}
        {tab === 'overview' && (
          <div className="space-y-5 slide-up">
            {/* KPI Grid */}
            <div className="grid grid-cols-2 gap-2.5">
              {[
                { label: 'Total Bookings', value: MOCK_BOOKINGS.length, change: '+12%', icon: CalendarCheck, color: 'text-orange-500', bg: 'bg-orange-500/10', border: 'border-orange-500/15' },
                { label: 'Active Technicians', value: activeTechnicians, change: `${MOCK_TECHNICIANS.length} total`, icon: Briefcase, color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/15' },
                { label: 'Pending Requests', value: pendingBookings, change: 'Needs assignment', icon: Clock, color: 'text-yellow-400', bg: 'bg-yellow-500/10', border: 'border-yellow-500/15' },
                { label: 'UPI Revenue', value: `₹${totalEarnings.toLocaleString()}`, change: '+18% MTD', icon: CreditCard, color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/15' },
              ].map(({ label, value, change, icon: Icon, color, bg, border }) => (
                <div key={label} className="glass rounded-2xl p-4 glass-card">
                  <div className={`w-9 h-9 rounded-xl ${bg} border ${border} flex items-center justify-center mb-2`}><Icon size={16} className={color} /></div>
                  <p className={`text-xl font-black ${color}`}>{value}</p>
                  <p className="text-[11px] text-white/45 font-semibold mt-0.5">{label}</p>
                  <p className="text-[10px] text-green-400/60 font-bold mt-1">{change}</p>
                </div>
              ))}
            </div>

            {/* Earnings Summary */}
            <div className="glass rounded-2xl p-4 glass-card">
              <div className="flex items-center justify-between mb-4">
                <div className="relative">
                  <h3 className="text-sm font-bold text-white/70">Earnings Summary</h3>
                  <div className="absolute -bottom-1 left-0 w-6 h-0.5 bg-orange-500/50 rounded-full" />
                </div>
                <span className="text-[10px] text-white/25">This month</span>
              </div>
              <div className="space-y-3">
                {[
                  { label: 'UPI Collections', amount: totalEarnings, pct: 85 },
                  { label: 'COD Pending', amount: 460, pct: 15 },
                  { label: 'Platform Fees', amount: 196, pct: 6 },
                ].map(({ label, amount, pct }) => (
                  <div key={label}>
                    <div className="flex justify-between text-xs mb-1.5">
                      <span className="text-white/40 font-medium">{label}</span>
                      <span className="text-white font-bold">₹{amount.toLocaleString()} ({pct}%)</span>
                    </div>
                    <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-orange-500 to-orange-600 rounded-full transition-all duration-700" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-2 gap-2.5">
              {[
                { icon: UserPlus, label: 'Add Technician', href: '/admin/technicians', color: 'text-orange-400', bg: 'bg-orange-500/10', border: 'border-orange-500/15' },
                { icon: QrCode, label: 'UPI Payments', href: '/admin/payments', color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/15' },
                { icon: Briefcase, label: 'Manage Techs', href: '/admin/technicians', color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/15' },
                { icon: TrendingUp, label: 'Reports', href: '#', color: 'text-teal-400', bg: 'bg-teal-500/10', border: 'border-teal-500/15' },
              ].map(({ icon: Icon, label, href, color, bg, border }) => (
                <Link key={label} href={href} className="glass rounded-2xl p-4 glass-card flex items-center gap-3 group">
                  <div className={`w-10 h-10 rounded-xl ${bg} border ${border} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                    <Icon size={18} className={color} />
                  </div>
                  <span className="text-sm font-semibold text-white/60 group-hover:text-white/80">{label}</span>
                  <ChevronRight size={14} className="text-white/15 ml-auto" />
                </Link>
              ))}
            </div>

            {/* Recent Bookings */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="relative"><h3 className="text-sm font-bold text-white/70">Recent Bookings</h3><div className="absolute -bottom-1 left-0 w-6 h-0.5 bg-orange-500/50 rounded-full" /></div>
                <button onClick={() => setTab('bookings')} className="text-[11px] text-orange-500 font-semibold">View All</button>
              </div>
              <div className="space-y-2">
                {MOCK_BOOKINGS.slice(0, 3).map(b => {
                  const sCfg = STATUS_CONFIG[b.status];
                  const BIcon = BOOKING_ICONS[b.serviceName] || Wind;
                  return (
                    <div key={b.id} className="glass rounded-xl p-3 flex items-center gap-3 glass-card">
                      <div className="w-9 h-9 rounded-lg bg-orange-500/10 border border-orange-500/15 flex items-center justify-center shrink-0"><BIcon size={14} className="text-orange-400" /></div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-white">{b.serviceName}</p>
                        <p className="text-[10px] text-white/20">{b.customerName} • {b.technicianName || 'Unassigned'}</p>
                      </div>
                      <span className={`text-[9px] font-bold px-2 py-0.5 rounded-lg border ${sCfg.color} ${sCfg.bg} ${sCfg.border}`}>{sCfg.label}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* BOOKINGS TAB */}
        {tab === 'bookings' && (
          <div className="space-y-4 slide-up">
            <div className="relative">
              <Search size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/25" />
              <input type="text" placeholder="Search bookings..." value={search} onChange={e => setSearch(e.target.value)}
                className="w-full glass rounded-2xl pl-10 pr-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-orange-500/40 transition-all" />
            </div>
            <div className="flex gap-1.5 overflow-x-auto scrollbar-hide">
              {['all', 'pending', 'confirmed', 'in_progress', 'completed', 'cancelled'].map(s => (
                <button key={s} onClick={() => setBookingFilter(s)}
                  className={`shrink-0 px-3 py-1.5 rounded-lg text-[10px] font-bold capitalize transition-all ${bookingFilter === s ? 'bg-orange-500/20 border border-orange-500/30 text-orange-400' : 'glass text-white/25'}`}>
                  {s.replace('_', ' ')}
                </button>
              ))}
            </div>
            <div className="space-y-2.5">
              {filteredBookings.map(b => {
                const sCfg = STATUS_CONFIG[b.status];
                const BIcon = BOOKING_ICONS[b.serviceName] || Wind;
                return (
                  <div key={b.id} className="glass rounded-2xl p-4 glass-card">
                    <div className="flex items-start gap-3 mb-2.5">
                      <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/15 flex items-center justify-center shrink-0"><BIcon size={16} className="text-orange-400" /></div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <p className="text-sm font-bold text-white">{b.serviceName}</p>
                            <p className="text-[10px] text-white/25">{b.customerName} • #{b.id}</p>
                          </div>
                          <span className={`text-[9px] font-bold px-2 py-0.5 rounded-lg border shrink-0 ${sCfg.color} ${sCfg.bg} ${sCfg.border}`}>{sCfg.label}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 text-[10px] text-white/25 mb-2.5">
                      <span>{b.scheduledDate}</span><span>|</span><span>{b.technicianName || 'Unassigned'}</span>
                    </div>
                    <div className="flex items-center justify-between pt-2.5 border-t border-white/[0.04]">
                      <span className="text-sm font-black text-gradient">₹{b.totalAmount}</span>
                      <div className="flex gap-2">
                        {b.status === 'pending' && <button onClick={() => handleBookingStatus(b.id, 'confirmed')} className="px-2.5 py-1 rounded-lg bg-green-500/10 border border-green-500/25 text-green-400 text-[10px] font-bold">Confirm</button>}
                        {b.status === 'confirmed' && <button onClick={() => handleBookingStatus(b.id, 'in_progress')} className="px-2.5 py-1 rounded-lg bg-orange-500/10 border border-orange-500/25 text-orange-400 text-[10px] font-bold">Start</button>}
                        {b.status === 'in_progress' && <button onClick={() => handleBookingStatus(b.id, 'completed')} className="px-2.5 py-1 rounded-lg bg-green-500/10 border border-green-500/25 text-green-400 text-[10px] font-bold">Complete</button>}
                        {['pending', 'confirmed'].includes(b.status) && <button onClick={() => handleBookingStatus(b.id, 'cancelled')} className="px-2.5 py-1 rounded-lg bg-red-500/10 border border-red-500/15 text-red-400/60 text-[10px] font-bold">Cancel</button>}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* UPI PAYMENTS TAB */}
        {tab === 'payments' && (
          <div className="space-y-4 slide-up">
            <div className="grid grid-cols-3 gap-2">
              {[
                { label: 'Collected', value: MOCK_UPI_PAYMENTS.filter(p => p.status === 'success').length, color: 'text-green-400' },
                { label: 'Pending', value: MOCK_UPI_PAYMENTS.filter(p => p.status === 'pending').length, color: 'text-yellow-400' },
                { label: 'Total Value', value: `₹${totalEarnings.toLocaleString()}`, color: 'text-orange-500' },
              ].map(({ label, value, color }) => (
                <div key={label} className="glass rounded-2xl p-3 text-center glass-card">
                  <p className={`text-base font-black ${color}`}>{value}</p>
                  <p className="text-[8px] text-white/25 uppercase tracking-wider font-semibold">{label}</p>
                </div>
              ))}
            </div>

            <div className="relative">
              <Search size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/25" />
              <input type="text" placeholder="Search by UPI ID, transaction ID..." value={search} onChange={e => setSearch(e.target.value)}
                className="w-full glass rounded-2xl pl-10 pr-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-orange-500/40 transition-all" />
            </div>

            <div className="space-y-2.5">
              {filteredPayments.map(p => {
                const pCfg = PAYMENT_STATUS_CONFIG[p.status];
                return (
                  <div key={p.id} className="glass rounded-2xl p-4 glass-card">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div>
                        <p className="text-sm font-bold text-white">{p.customerName}</p>
                        <p className="text-[10px] text-white/25 mt-0.5">{p.upiId} • {p.paymentMethod.toUpperCase()}</p>
                      </div>
                      <span className={`text-[9px] font-bold px-2 py-0.5 rounded-lg border ${pCfg.color} ${pCfg.bg} ${pCfg.border}`}>{pCfg.label}</span>
                    </div>
                    <div className="flex items-center justify-between pt-2.5 border-t border-white/[0.04]">
                      <div>
                        <p className="text-base font-black text-gradient">₹{p.amount}</p>
                        {p.transactionId && <p className="text-[9px] text-white/15 mt-0.5">TXN: {p.transactionId}</p>}
                      </div>
                      <p className="text-[10px] text-white/20">{p.createdAt}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            <Link href="/admin/payments" className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl border border-orange-500/25 text-orange-500/70 text-sm font-semibold hover:bg-orange-500/5 transition-all">
              View All Payment Records <ChevronRight size={14} />
            </Link>
          </div>
        )}

        {/* TECHNICIANS TAB */}
        {tab === 'technicians' && (
          <div className="space-y-4 slide-up">
            <div className="grid grid-cols-3 gap-2">
              {[
                { label: 'Active', value: activeTechnicians, color: 'text-green-400' },
                { label: 'Blocked', value: MOCK_TECHNICIANS.filter(t => t.status === 'blocked').length, color: 'text-red-400' },
                { label: 'Total', value: MOCK_TECHNICIANS.length, color: 'text-white' },
              ].map(({ label, value, color }) => (
                <div key={label} className="glass rounded-2xl p-3 text-center glass-card">
                  <p className={`text-base font-black ${color}`}>{value}</p>
                  <p className="text-[8px] text-white/25 uppercase tracking-wider font-semibold">{label}</p>
                </div>
              ))}
            </div>
            <Link href="/admin/technicians" className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 to-orange-600 text-black font-bold py-3.5 rounded-2xl">
              <UserPlus size={16} /> Manage Technicians
            </Link>
            <div className="space-y-2">
              {MOCK_TECHNICIANS.filter(t => t.status === 'active').slice(0, 4).map(t => (
                <div key={t.id} className="glass rounded-xl p-3 flex items-center gap-3 glass-card">
                  <div className="w-10 h-10 rounded-lg bg-orange-500/10 border border-orange-500/15 flex items-center justify-center shrink-0">
                    <span className="text-sm font-bold text-orange-500">{t.fullName[0]}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-white">{t.fullName}</p>
                    <p className="text-[10px] text-white/20">{t.techId} • {t.assignedServices.join(', ')}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-xs font-black text-gradient">₹{t.totalEarnings.toLocaleString()}</p>
                    <p className="text-[9px] text-white/20">{t.totalJobs} jobs</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}

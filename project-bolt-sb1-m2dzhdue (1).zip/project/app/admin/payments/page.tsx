'use client';

import { useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowLeft, Search, CreditCard, QrCode, Smartphone, Download, Filter } from 'lucide-react';
import { MOCK_UPI_PAYMENTS, PAYMENT_STATUS_CONFIG } from '@/lib/mock-data';

type PayFilter = 'all' | 'success' | 'pending' | 'failed';

export default function AdminPaymentsPage() {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<PayFilter>('all');

  const filtered = MOCK_UPI_PAYMENTS.filter(p => {
    const matchSearch = p.customerName.toLowerCase().includes(search.toLowerCase()) ||
      p.transactionId.toLowerCase().includes(search.toLowerCase()) ||
      p.upiId.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'all' || p.status === filter;
    return matchSearch && matchFilter;
  });

  const totalCollected = MOCK_UPI_PAYMENTS.filter(p => p.status === 'success').reduce((a, p) => a + p.amount, 0);
  const totalPending = MOCK_UPI_PAYMENTS.filter(p => p.status === 'pending').reduce((a, p) => a + p.amount, 0);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }} className="min-h-screen bg-[#070707] pb-10">
      <div className="sticky top-0 z-40 glass-strong border-b border-white/[0.04]">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center gap-3">
          <Link href="/admin" className="p-1.5 rounded-xl hover:bg-white/5"><ArrowLeft size={18} className="text-white/60" /></Link>
          <h1 className="text-base font-bold text-white">UPI Payment Records</h1>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 pt-4">
        {/* Summary */}
        <div className="grid grid-cols-2 gap-2.5 mb-5">
          <div className="glass-orange rounded-2xl p-4 glass-card">
            <p className="text-xl font-black text-gradient">₹{totalCollected.toLocaleString()}</p>
            <p className="text-[10px] text-white/35 font-semibold mt-0.5">Total Collected</p>
          </div>
          <div className="glass rounded-2xl p-4 glass-card">
            <p className="text-xl font-black text-yellow-400">₹{totalPending.toLocaleString()}</p>
            <p className="text-[10px] text-white/35 font-semibold mt-0.5">Pending Collection</p>
          </div>
        </div>

        {/* Search & Filter */}
        <div className="flex gap-2 mb-4">
          <div className="relative flex-1">
            <Search size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/25" />
            <input type="text" placeholder="Search UPI ID, TXN ID..." value={search} onChange={e => setSearch(e.target.value)}
              className="w-full glass rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-orange-500/40 transition-all" />
          </div>
          <button className="flex items-center gap-1.5 glass rounded-xl px-3 text-white/40 text-xs font-semibold"><Download size={12} /> Export</button>
        </div>

        <div className="flex gap-1.5 mb-4 overflow-x-auto scrollbar-hide">
          {(['all', 'success', 'pending', 'failed'] as PayFilter[]).map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`shrink-0 px-3 py-1.5 rounded-lg text-[10px] font-bold capitalize transition-all ${filter === f ? 'bg-orange-500/20 border border-orange-500/30 text-orange-400' : 'glass text-white/25'}`}>
              {f}
            </button>
          ))}
        </div>

        {/* Payment Cards */}
        <div className="space-y-2.5">
          {filtered.map(p => {
            const cfg = PAYMENT_STATUS_CONFIG[p.status];
            return (
              <div key={p.id} className="glass rounded-2xl p-4 glass-card">
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/15 flex items-center justify-center shrink-0">
                      {p.paymentMethod === 'qr' ? <QrCode size={16} className="text-orange-400" /> :
                       p.paymentMethod === 'upi' ? <Smartphone size={16} className="text-orange-400" /> :
                       <CreditCard size={16} className="text-orange-400" />}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-white">{p.customerName}</p>
                      <p className="text-[10px] text-white/25">{p.upiId}</p>
                    </div>
                  </div>
                  <span className={`text-[9px] font-bold px-2 py-0.5 rounded-lg border ${cfg.color} ${cfg.bg} ${cfg.border}`}>{cfg.label}</span>
                </div>
                <div className="space-y-1.5 mb-3">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-white/25">Method</span>
                    <span className="text-white/50 font-medium">{p.paymentMethod.toUpperCase()}</span>
                  </div>
                  {p.transactionId && (
                    <div className="flex justify-between text-[11px]">
                      <span className="text-white/25">Transaction ID</span>
                      <span className="text-white/50 font-mono text-[10px]">{p.transactionId}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-[11px]">
                    <span className="text-white/25">Booking</span>
                    <span className="text-white/50">#{p.bookingId}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between pt-2.5 border-t border-white/[0.04]">
                  <p className="text-base font-black text-gradient">₹{p.amount}</p>
                  <p className="text-[10px] text-white/15">{p.createdAt}</p>
                </div>
              </div>
            );
          })}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-12">
            <CreditCard size={32} className="text-white/8 mx-auto mb-2" />
            <p className="text-white/20 text-sm">No payments found</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}

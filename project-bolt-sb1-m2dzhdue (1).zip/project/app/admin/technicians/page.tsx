'use client';

import { useState } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import type { LucideIcon } from 'lucide-react';
import { ArrowLeft, Search, Plus, Shield, UserCheck, UserX, Trash2, Edit, Eye, Phone, Star, MapPin, Briefcase, Users } from 'lucide-react';
import { MOCK_TECHNICIANS, TECHNICIAN_STATUS_CONFIG, SERVICE_CATEGORIES, type Technician } from '@/lib/mock-data';

type ViewMode = 'list' | 'create' | 'edit' | 'view';

const emptyTech: Omit<Technician, 'id' | 'createdAt' | 'rating' | 'totalJobs' | 'totalEarnings' | 'isAvailable'> = {
  techId: '', username: '', password: '', fullName: '', phone: '',
  assignedCategory: 'home', assignedServices: [], city: 'Chennai', status: 'active',
};

export default function AdminTechniciansPage() {
  const [view, setView] = useState<ViewMode>('list');
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [technicians, setTechnicians] = useState(MOCK_TECHNICIANS);
  const [formData, setFormData] = useState(emptyTech);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [viewTech, setViewTech] = useState<Technician | null>(null);
  const [showPassword, setShowPassword] = useState(false);

  const filtered = technicians.filter(t => {
    const matchSearch = t.fullName.toLowerCase().includes(search.toLowerCase()) ||
      t.techId.toLowerCase().includes(search.toLowerCase()) ||
      t.username.toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === 'all' || t.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const stats = {
    total: technicians.length,
    active: technicians.filter(t => t.status === 'active').length,
    blocked: technicians.filter(t => t.status === 'blocked').length,
    removed: technicians.filter(t => t.status === 'removed').length,
  };

  const nextTechId = () => {
    const maxNum = technicians.reduce((max, t) => {
      const n = parseInt(t.techId.replace('TECH-', ''));
      return n > max ? n : max;
    }, 0);
    return `TECH-${String(maxNum + 1).padStart(3, '0')}`;
  };

  const handleCreate = () => {
    if (!formData.fullName || !formData.username || !formData.password) return;
    const newTech: Technician = {
      ...formData,
      id: `t${Date.now()}`,
      techId: nextTechId(),
      rating: 0, totalJobs: 0, totalEarnings: 0, isAvailable: true,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setTechnicians(prev => [...prev, newTech]);
    setFormData(emptyTech);
    setView('list');
  };

  const handleEdit = () => {
    if (!editingId) return;
    setTechnicians(prev => prev.map(t => t.id === editingId ? { ...t, ...formData } : t));
    setEditingId(null);
    setFormData(emptyTech);
    setView('list');
  };

  const handleStatusChange = (id: string, status: Technician['status']) => {
    setTechnicians(prev => prev.map(t => t.id === id ? { ...t, status, isAvailable: status === 'active' } : t));
  };

  const handleRemove = (id: string) => {
    setTechnicians(prev => prev.map(t => t.id === id ? { ...t, status: 'removed', isAvailable: false } : t));
  };

  const startEdit = (tech: Technician) => {
    setEditingId(tech.id);
    setFormData({
      techId: tech.techId, username: tech.username, password: tech.password,
      fullName: tech.fullName, phone: tech.phone, assignedCategory: tech.assignedCategory,
      assignedServices: tech.assignedServices, city: tech.city, status: tech.status,
    });
    setView('edit');
  };

  const selectedCategory = SERVICE_CATEGORIES.find(c => c.id === formData.assignedCategory);
  const toggleService = (service: string) => {
    setFormData(prev => ({
      ...prev,
      assignedServices: prev.assignedServices.includes(service)
        ? prev.assignedServices.filter(s => s !== service)
        : [...prev.assignedServices, service],
    }));
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }} className="min-h-screen bg-[#070707] pb-10">
      {/* Header */}
      <div className="sticky top-0 z-40 glass-strong border-b border-white/[0.04]">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/admin" className="p-1.5 rounded-xl hover:bg-white/5"><ArrowLeft size={18} className="text-white/60" /></Link>
            <div>
              <h1 className="text-base font-bold text-white">Technician Management</h1>
              <p className="text-[9px] text-orange-500/70 font-bold tracking-wider uppercase">Admin Only</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 bg-red-500/10 border border-red-500/20 px-2.5 py-1 rounded-xl">
            <Shield size={11} className="text-red-400" />
            <span className="text-[10px] text-red-400 font-bold">ADMIN</span>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 pt-4">
        {/* LIST VIEW */}
        {view === 'list' && (
          <div className="space-y-4 slide-up">
            {/* Stats */}
            <div className="grid grid-cols-4 gap-2">
              {[
                { label: 'Total', value: stats.total, color: 'text-white' },
                { label: 'Active', value: stats.active, color: 'text-green-400' },
                { label: 'Blocked', value: stats.blocked, color: 'text-red-400' },
                { label: 'Removed', value: stats.removed, color: 'text-white/40' },
              ].map(({ label, value, color }) => (
                <div key={label} className="glass rounded-2xl p-3 text-center glass-card">
                  <p className={`text-lg font-black ${color}`}>{value}</p>
                  <p className="text-[8px] text-white/25 uppercase tracking-wider font-semibold">{label}</p>
                </div>
              ))}
            </div>

            {/* Search & Filter */}
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/25" />
                <input type="text" placeholder="Search technicians..." value={search} onChange={e => setSearch(e.target.value)}
                  className="w-full glass rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-orange-500/40 transition-all" />
              </div>
              <button onClick={() => setView('create')}
                className="flex items-center gap-1.5 bg-gradient-to-r from-orange-500 to-orange-600 text-black font-bold px-4 py-3 rounded-xl text-sm shrink-0 glow-orange-xs">
                <Plus size={14} /> Add
              </button>
            </div>

            {/* Status Filter */}
            <div className="flex gap-1.5 overflow-x-auto scrollbar-hide">
              {['all', 'active', 'blocked', 'removed'].map(s => (
                <button key={s} onClick={() => setFilterStatus(s)}
                  className={`shrink-0 px-3 py-1.5 rounded-lg text-[11px] font-bold capitalize transition-all ${filterStatus === s ? 'bg-orange-500/20 border border-orange-500/30 text-orange-400' : 'glass text-white/30'}`}>
                  {s}
                </button>
              ))}
            </div>

            {/* Technician Cards */}
            <div className="space-y-2.5">
              {filtered.map(tech => {
                const cfg = TECHNICIAN_STATUS_CONFIG[tech.status];
                return (
                  <div key={tech.id} className="glass rounded-2xl p-4 glass-card">
                    <div className="flex items-start gap-3.5">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-500/20 to-orange-600/5 border border-orange-500/20 flex items-center justify-center shrink-0">
                        <span className="text-lg font-black text-orange-500">{tech.fullName[0]}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <p className="text-sm font-bold text-white">{tech.fullName}</p>
                            <p className="text-[10px] text-white/25 mt-0.5">{tech.techId} • {tech.username}</p>
                          </div>
                          <span className={`text-[9px] font-bold px-2 py-0.5 rounded-lg border shrink-0 ${cfg.color} ${cfg.bg} ${cfg.border}`}>{cfg.label}</span>
                        </div>
                        <div className="flex items-center gap-3 mt-2">
                          <span className="flex items-center gap-1 text-[10px] text-white/25"><Phone size={9} />{tech.phone}</span>
                          <span className="flex items-center gap-1 text-[10px] text-white/25"><MapPin size={9} />{tech.city}</span>
                          <span className="flex items-center gap-1 text-[10px] text-white/25"><Star size={9} className="text-orange-500" />{tech.rating}</span>
                        </div>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {tech.assignedServices.map(s => (
                            <span key={s} className="text-[9px] bg-orange-500/8 border border-orange-500/15 text-orange-400/60 px-2 py-0.5 rounded-full font-medium">{s}</span>
                          ))}
                        </div>
                        <div className="flex items-center gap-2 mt-3 pt-2.5 border-t border-white/[0.04]">
                          <button onClick={() => { setViewTech(tech); setView('view'); }}
                            className="flex items-center gap-1 px-2.5 py-1 rounded-lg glass text-white/40 text-[11px] font-semibold hover:text-white/60 transition-colors"><Eye size={10} />View</button>
                          <button onClick={() => startEdit(tech)}
                            className="flex items-center gap-1 px-2.5 py-1 rounded-lg glass text-blue-400/70 text-[11px] font-semibold hover:text-blue-400 transition-colors"><Edit size={10} />Edit</button>
                          {tech.status === 'active' && (
                            <button onClick={() => handleStatusChange(tech.id, 'blocked')}
                              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-red-500/5 border border-red-500/15 text-red-400/70 text-[11px] font-semibold hover:text-red-400 transition-colors"><UserX size={10} />Block</button>
                          )}
                          {tech.status === 'blocked' && (
                            <button onClick={() => handleStatusChange(tech.id, 'active')}
                              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-green-500/5 border border-green-500/15 text-green-400/70 text-[11px] font-semibold hover:text-green-400 transition-colors"><UserCheck size={10} />Activate</button>
                          )}
                          {tech.status !== 'removed' && (
                            <button onClick={() => handleRemove(tech.id)}
                              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white/[0.02] border border-white/[0.06] text-white/20 text-[11px] font-semibold hover:text-white/40 transition-colors ml-auto"><Trash2 size={10} /></button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {filtered.length === 0 && (
              <div className="text-center py-12"><Users size={32} className="text-white/8 mx-auto mb-2" /><p className="text-white/20 text-sm">No technicians found</p></div>
            )}
          </div>
        )}

        {/* CREATE / EDIT VIEW */}
        {(view === 'create' || view === 'edit') && (
          <div className="space-y-4 slide-up">
            <div className="flex items-center gap-2 mb-2">
              <button onClick={() => { setView('list'); setFormData(emptyTech); setEditingId(null); }} className="text-white/35 hover:text-white/60 text-sm font-medium">
                Back to list
              </button>
            </div>
            <h2 className="text-xl font-black text-white">{view === 'create' ? 'Create Technician' : 'Edit Technician'}</h2>
            <p className="text-white/30 text-xs">{view === 'create' ? 'Only admin can create technician accounts' : 'Update technician details'}</p>

            <div className="glass rounded-2xl p-5 space-y-4">
              {view === 'create' && (
                <div className="glass-orange rounded-xl p-3 mb-2">
                  <p className="text-[11px] text-orange-400 font-semibold">Auto-generated Technician ID: <span className="font-black">{nextTechId()}</span></p>
                </div>
              )}

              {/* Full Name */}
              <div>
                <label className="text-[11px] font-semibold text-white/40 mb-1.5 block uppercase tracking-wider">Full Name *</label>
                <input type="text" placeholder="Technician full name" value={formData.fullName} onChange={e => setFormData(p => ({ ...p, fullName: e.target.value }))}
                  className="w-full glass rounded-xl px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-orange-500/40 transition-all" />
              </div>

              {/* Username & Password */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-white/40 mb-1.5 block uppercase tracking-wider">Username *</label>
                  <input type="text" placeholder="login.username" value={formData.username} onChange={e => setFormData(p => ({ ...p, username: e.target.value }))}
                    className="w-full glass rounded-xl px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-orange-500/40 transition-all" />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-white/40 mb-1.5 block uppercase tracking-wider">Password *</label>
                  <div className="relative">
                    <input type={showPassword ? 'text' : 'password'} placeholder="Strong password" value={formData.password} onChange={e => setFormData(p => ({ ...p, password: e.target.value }))}
                      className="w-full glass rounded-xl px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-orange-500/40 transition-all pr-16" />
                    <button type="button" onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-orange-400/60 font-semibold">{showPassword ? 'Hide' : 'Show'}</button>
                  </div>
                </div>
              </div>

              {/* Phone & City */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-white/40 mb-1.5 block uppercase tracking-wider">Phone</label>
                  <input type="tel" placeholder="+91 98765 43210" value={formData.phone} onChange={e => setFormData(p => ({ ...p, phone: e.target.value }))}
                    className="w-full glass rounded-xl px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-orange-500/40 transition-all" />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-white/40 mb-1.5 block uppercase tracking-wider">City</label>
                  <input type="text" placeholder="Chennai" value={formData.city} onChange={e => setFormData(p => ({ ...p, city: e.target.value }))}
                    className="w-full glass rounded-xl px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-orange-500/40 transition-all" />
                </div>
              </div>

              {/* Category */}
              <div>
                <label className="text-[11px] font-semibold text-white/40 mb-2 block uppercase tracking-wider">Assigned Category *</label>
                <div className="flex gap-2">
                  {SERVICE_CATEGORIES.map(cat => (
                    <button key={cat.id} onClick={() => setFormData(p => ({ ...p, assignedCategory: cat.id, assignedServices: [] }))}
                      className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all ${formData.assignedCategory === cat.id ? 'bg-gradient-to-r from-orange-500 to-orange-600 text-black' : 'glass text-white/40'}`}>
                      {cat.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Services */}
              {selectedCategory && (
                <div>
                  <label className="text-[11px] font-semibold text-white/40 mb-2 block uppercase tracking-wider">Assigned Services</label>
                  <div className="flex flex-wrap gap-2">
                    {selectedCategory.services.map(svc => (
                      <button key={svc} onClick={() => toggleService(svc)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${formData.assignedServices.includes(svc) ? 'bg-orange-500/15 border border-orange-500/30 text-orange-400' : 'glass text-white/30'}`}>
                        {svc}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <button onClick={view === 'create' ? handleCreate : handleEdit}
                disabled={!formData.fullName || !formData.username || !formData.password}
                className="w-full bg-gradient-to-r from-orange-500 to-orange-600 disabled:opacity-40 text-black font-bold py-3.5 rounded-2xl transition-all">
                {view === 'create' ? 'Create Technician Account' : 'Save Changes'}
              </button>
            </div>
          </div>
        )}

        {/* VIEW DETAIL */}
        {view === 'view' && viewTech && (
          <div className="space-y-4 slide-up">
            <button onClick={() => setView('list')} className="text-white/35 hover:text-white/60 text-sm font-medium">Back to list</button>

            <div className="glass-orange rounded-2xl p-5">
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-500/25 to-orange-600/10 border border-orange-500/25 flex items-center justify-center">
                  <span className="text-2xl font-black text-orange-500">{viewTech.fullName[0]}</span>
                </div>
                <div className="flex-1">
                  <h2 className="text-lg font-black text-white">{viewTech.fullName}</h2>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[10px] font-bold text-orange-400 bg-orange-500/10 border border-orange-500/20 px-2 py-0.5 rounded-full">{viewTech.techId}</span>
                    <span className={`text-[9px] font-bold px-2 py-0.5 rounded-lg border ${TECHNICIAN_STATUS_CONFIG[viewTech.status].color} ${TECHNICIAN_STATUS_CONFIG[viewTech.status].bg} ${TECHNICIAN_STATUS_CONFIG[viewTech.status].border}`}>
                      {TECHNICIAN_STATUS_CONFIG[viewTech.status].label}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Login Credentials */}
            <div className="glass rounded-2xl p-4">
              <p className="text-[10px] font-bold text-white/25 uppercase tracking-wider mb-3">Login Credentials</p>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-white/[0.03] rounded-xl p-3">
                  <p className="text-[10px] text-white/25">Username</p>
                  <p className="text-sm font-bold text-white mt-0.5">{viewTech.username}</p>
                </div>
                <div className="bg-white/[0.03] rounded-xl p-3">
                  <p className="text-[10px] text-white/25">Password</p>
                  <p className="text-sm font-bold text-white mt-0.5">{showPassword ? viewTech.password : '********'}</p>
                  <button onClick={() => setShowPassword(!showPassword)} className="text-[9px] text-orange-400/60 mt-1 font-semibold">{showPassword ? 'Hide' : 'Reveal'}</button>
                </div>
              </div>
            </div>

            {/* Details */}
            <div className="glass rounded-2xl p-4 space-y-3">
              <p className="text-[10px] font-bold text-white/25 uppercase tracking-wider mb-2">Details</p>
              {[
                { icon: Phone, label: 'Phone', value: viewTech.phone },
                { icon: MapPin, label: 'City', value: viewTech.city },
                { icon: Briefcase, label: 'Category', value: viewTech.assignedCategory },
                { icon: Star, label: 'Rating', value: `${viewTech.rating} (${viewTech.totalJobs} jobs)` },
              ].map(({ icon: Icon, label, value }) => (
                <div key={label} className="flex items-center gap-3">
                  <Icon size={13} className="text-orange-500/50" />
                  <span className="text-[11px] text-white/30">{label}:</span>
                  <span className="text-[11px] text-white/70 font-medium">{value}</span>
                </div>
              ))}
              <div className="pt-2">
                <p className="text-[10px] text-white/25 mb-1.5">Services</p>
                <div className="flex flex-wrap gap-1.5">
                  {viewTech.assignedServices.map(s => (
                    <span key={s} className="text-[10px] bg-orange-500/8 border border-orange-500/15 text-orange-400/60 px-2 py-0.5 rounded-full font-medium">{s}</span>
                  ))}
                </div>
              </div>
            </div>

            {/* Earnings Summary */}
            <div className="glass rounded-2xl p-4">
              <p className="text-[10px] font-bold text-white/25 uppercase tracking-wider mb-3">Earnings</p>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-white/[0.03] rounded-xl p-3 text-center">
                  <p className="text-lg font-black text-gradient">₹{viewTech.totalEarnings.toLocaleString()}</p>
                  <p className="text-[9px] text-white/25 uppercase tracking-wider">Total Earned</p>
                </div>
                <div className="bg-white/[0.03] rounded-xl p-3 text-center">
                  <p className="text-lg font-black text-white">{viewTech.totalJobs}</p>
                  <p className="text-[9px] text-white/25 uppercase tracking-wider">Jobs Done</p>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              <button onClick={() => startEdit(viewTech)} className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 to-orange-600 text-black font-bold py-3 rounded-2xl">
                <Edit size={14} /> Edit
              </button>
              {viewTech.status === 'active' && (
                <button onClick={() => { handleStatusChange(viewTech.id, 'blocked'); setViewTech({ ...viewTech, status: 'blocked' }); }}
                  className="flex-1 flex items-center justify-center gap-2 bg-red-500/10 border border-red-500/25 text-red-400 font-bold py-3 rounded-2xl">
                  <UserX size={14} /> Block
                </button>
              )}
              {viewTech.status === 'blocked' && (
                <button onClick={() => { handleStatusChange(viewTech.id, 'active'); setViewTech({ ...viewTech, status: 'active' }); }}
                  className="flex-1 flex items-center justify-center gap-2 bg-green-500/10 border border-green-500/25 text-green-400 font-bold py-3 rounded-2xl">
                  <UserCheck size={14} /> Activate
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}

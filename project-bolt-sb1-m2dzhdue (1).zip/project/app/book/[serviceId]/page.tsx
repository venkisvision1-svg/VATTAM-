'use client';

import { useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import type { LucideIcon } from 'lucide-react';
import { ArrowLeft, Wind, Camera, Droplets, Zap, Thermometer, RefreshCw, CheckCircle, MapPin, Calendar, Clock, CreditCard, Shield } from 'lucide-react';
import { SERVICES, TIME_SLOTS } from '@/lib/services-data';
import BottomNav from '@/components/BottomNav';
import UPIPaymentFlow from '@/components/UPIPaymentFlow';

const ICON_MAP: Record<string, LucideIcon> = {
  Wind, Camera, Droplets, Zap, Thermometer, RefreshCw,
};

type BookingStep = 'details' | 'schedule' | 'payment' | 'upi_pay' | 'confirm';
const STEPS = ['Details', 'Schedule', 'Payment', 'Pay', 'Confirm'];

export default function BookPage() {
  const params = useParams();
  const router = useRouter();
  const serviceId = params.serviceId as string;
  const service = SERVICES.find(s => s.id === serviceId);

  const [step, setStep] = useState<BookingStep>('details');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [payMethod, setPayMethod] = useState<'upi' | 'card' | 'cod'>('upi');
  const [loading, setLoading] = useState(false);
  const [booked, setBooked] = useState(false);

  if (!service) {
    return (
      <div className="min-h-screen bg-[#070707] flex items-center justify-center">
        <div className="text-center">
          <p className="text-white/30">Service not found</p>
          <Link href="/services" className="text-orange-500 mt-2 block text-sm font-semibold">Browse Services</Link>
        </div>
      </div>
    );
  }

  const Icon = ICON_MAP[service.icon] || Wind;
  const stepIndex = STEPS.findIndex(s => s.toLowerCase() === step);
  const total = service.basePrice + 49 + Math.round(service.basePrice * 0.18);

  const handleBooking = async () => {
    setLoading(true);
    await new Promise(r => setTimeout(r, 1500));
    setLoading(false);
    setBooked(true);
    setTimeout(() => router.push('/bookings'), 2000);
  };

  if (booked) {
    return (
      <div className="min-h-screen bg-[#070707] flex items-center justify-center px-4">
        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: 'spring', stiffness: 200 }} className="text-center">
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.2, type: 'spring' }} className="w-24 h-24 rounded-3xl bg-green-500/15 border border-green-500/25 flex items-center justify-center mx-auto mb-5 glow-green">
            <CheckCircle size={44} className="text-green-500" />
          </motion.div>
          <h2 className="text-2xl font-black text-white mb-2">Booking Confirmed!</h2>
          <p className="text-white/40 text-sm mb-1">Your {service.name} has been booked</p>
          <p className="text-white/20 text-xs">Redirecting to your bookings...</p>
        </motion.div>
      </div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }} className="min-h-screen bg-[#070707] pb-24">
      <div className="sticky top-0 z-40 glass-strong border-b border-white/[0.04]">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center gap-3">
          <Link href="/services" className="p-1.5 rounded-xl hover:bg-white/5 transition-colors">
            <ArrowLeft size={18} className="text-white/60" />
          </Link>
          <h1 className="text-sm font-bold text-white flex-1">Book {service.name}</h1>
        </div>
        <div className="max-w-lg mx-auto px-4 pb-3">
          <div className="flex items-center gap-1.5">
            {STEPS.map((s, i) => (
              <div key={s} className="flex items-center gap-1.5 flex-1">
                <motion.div animate={{ scale: i === stepIndex ? 1.1 : 1 }} transition={{ type: 'spring', stiffness: 300 }}
                  className={`w-6 h-6 rounded-lg flex items-center justify-center text-[10px] font-bold transition-all duration-300 ${
                    i < stepIndex ? 'bg-green-500/20 border border-green-500/25 text-green-400' :
                    i === stepIndex ? 'bg-gradient-to-br from-orange-500 to-orange-600 text-black' :
                    'glass text-white/25'
                  }`}>
                  {i < stepIndex ? <CheckCircle size={12} /> : i + 1}
                </motion.div>
                {i < STEPS.length - 1 && <div className={`flex-1 h-px rounded-full transition-colors duration-500 ${i < stepIndex ? 'bg-green-500/30' : 'bg-white/8'}`} />}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 pt-4">
        <motion.div layoutId="service-summary" className="glass-orange rounded-2xl p-4 mb-5 flex items-center gap-3.5">
          <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${service.color} flex items-center justify-center shrink-0`}>
            <Icon size={24} className={service.iconColor} />
          </div>
          <div className="flex-1">
            <h3 className="font-bold text-white">{service.name}</h3>
            <p className="text-[11px] text-white/35">{service.description}</p>
            <div className="flex items-center gap-3 mt-1">
              <span className="text-gradient font-black">₹{service.basePrice}</span>
              <span className="flex items-center gap-1 text-white/25 text-[10px]"><Clock size={10} /> {service.duration}</span>
            </div>
          </div>
        </motion.div>

        <AnimatePresence mode="wait">
          {step === 'details' && (
            <motion.div key="details" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} transition={{ duration: 0.35 }} className="space-y-4">
              <div>
                <label className="text-[11px] font-semibold text-white/40 mb-2 block uppercase tracking-wider">Service Address *</label>
                <div className="relative">
                  <MapPin size={14} className="absolute left-4 top-3.5 text-white/25" />
                  <textarea placeholder="Enter your full address..." value={address} onChange={e => setAddress(e.target.value)} rows={3}
                    className="w-full glass rounded-2xl pl-10 pr-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-orange-500/40 transition-all resize-none" />
                </div>
              </div>
              <div>
                <label className="text-[11px] font-semibold text-white/40 mb-2 block uppercase tracking-wider">Additional Notes</label>
                <textarea placeholder="Special instructions for the technician..." value={notes} onChange={e => setNotes(e.target.value)} rows={2}
                  className="w-full glass rounded-2xl px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-orange-500/40 transition-all resize-none" />
              </div>
              <div className="glass rounded-2xl p-4">
                <p className="text-[11px] font-semibold text-white/40 mb-3 uppercase tracking-wider">What&apos;s Included:</p>
                <div className="grid grid-cols-2 gap-2">
                  {service.features.map(f => (
                    <div key={f} className="flex items-center gap-2"><CheckCircle size={12} className="text-orange-500" /><span className="text-[11px] text-white/50">{f}</span></div>
                  ))}
                </div>
              </div>
              <motion.button whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.99 }} onClick={() => address.trim() && setStep('schedule')} disabled={!address.trim()}
                className="w-full bg-gradient-to-r from-orange-500 to-orange-600 disabled:opacity-40 text-black font-bold py-3.5 rounded-2xl transition-all duration-300">
                Continue to Schedule
              </motion.button>
            </motion.div>
          )}

          {step === 'schedule' && (
            <motion.div key="schedule" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} transition={{ duration: 0.35 }} className="space-y-4">
              <div>
                <label className="text-[11px] font-semibold text-white/40 mb-2 block uppercase tracking-wider">Select Date</label>
                <div className="relative">
                  <Calendar size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/25" />
                  <input type="date" value={date} min={new Date().toISOString().split('T')[0]} onChange={e => setDate(e.target.value)}
                    className="w-full glass rounded-2xl pl-10 pr-4 py-3.5 text-sm text-white focus:outline-none focus:border-orange-500/40 transition-all [color-scheme:dark]" />
                </div>
              </div>
              <div>
                <label className="text-[11px] font-semibold text-white/40 mb-3 block uppercase tracking-wider">Select Time Slot</label>
                <div className="grid grid-cols-3 gap-2">
                  {TIME_SLOTS.map(slot => (
                    <motion.button key={slot} whileTap={{ scale: 0.95 }} onClick={() => setTime(slot)}
                      className={`py-2.5 rounded-xl text-xs font-semibold transition-all duration-300 ${
                        time === slot ? 'bg-gradient-to-r from-orange-500 to-orange-600 text-black font-bold glow-orange-xs' : 'glass text-white/40 hover:border-orange-500/20'
                      }`}>{slot}</motion.button>
                  ))}
                </div>
              </div>
              <div className="flex gap-3">
                <button onClick={() => setStep('details')} className="flex-1 py-3.5 rounded-2xl glass text-white/40 text-sm font-semibold">Back</button>
                <motion.button whileTap={{ scale: 0.98 }} onClick={() => date && time && setStep('payment')} disabled={!date || !time}
                  className="flex-1 bg-gradient-to-r from-orange-500 to-orange-600 disabled:opacity-40 text-black font-bold py-3.5 rounded-2xl transition-all">Continue</motion.button>
              </div>
            </motion.div>
          )}

          {step === 'payment' && (
            <motion.div key="payment" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} transition={{ duration: 0.35 }} className="space-y-4">
              <div>
                <label className="text-[11px] font-semibold text-white/40 mb-3 block uppercase tracking-wider">Payment Method</label>
                <div className="space-y-2">
                  {[
                    { id: 'upi' as const, label: 'UPI Payment', desc: 'GPay, PhonePe, Paytm', icon: '₹' },
                    { id: 'card' as const, label: 'Credit / Debit Card', desc: 'Visa, Mastercard, RuPay', icon: '💳' },
                    { id: 'cod' as const, label: 'Cash on Delivery', desc: 'Pay after service completion', icon: '💵' },
                  ].map(method => (
                    <motion.button key={method.id} whileTap={{ scale: 0.98 }} onClick={() => setPayMethod(method.id)}
                      className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all duration-300 text-left ${payMethod === method.id ? 'glass-orange' : 'glass glass-card'}`}>
                      <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-lg ${payMethod === method.id ? 'bg-orange-500/20' : 'bg-white/5'}`}>{method.icon}</div>
                      <div className="flex-1">
                        <p className={`text-sm font-semibold ${payMethod === method.id ? 'text-orange-400' : 'text-white/70'}`}>{method.label}</p>
                        <p className="text-[11px] text-white/30">{method.desc}</p>
                      </div>
                      <div className={`w-5 h-5 rounded-full border-2 transition-colors ${payMethod === method.id ? 'border-orange-500 bg-orange-500' : 'border-white/15'}`}>
                        {payMethod === method.id && <div className="w-full h-full rounded-full bg-black scale-50" />}
                      </div>
                    </motion.button>
                  ))}
                </div>
              </div>
              <div className="glass rounded-2xl p-4 space-y-2.5">
                <p className="text-sm font-bold text-white/70 mb-2">Price Breakdown</p>
                {[
                  { label: 'Service Charge', value: `₹${service.basePrice}` },
                  { label: 'Platform Fee', value: '₹49' },
                  { label: 'Tax (18% GST)', value: `₹${Math.round(service.basePrice * 0.18)}` },
                ].map(({ label, value }) => (
                  <div key={label} className="flex justify-between text-xs text-white/35"><span>{label}</span><span>{value}</span></div>
                ))}
                <div className="border-t border-white/[0.04] pt-2.5 flex justify-between">
                  <span className="font-bold text-white/80">Total</span>
                  <span className="font-black text-xl text-gradient">₹{total}</span>
                </div>
              </div>
              {payMethod !== 'cod' && (
                <div className="flex items-center gap-2.5 glass rounded-xl p-3.5">
                  <CreditCard size={14} className="text-blue-400 shrink-0" />
                  <p className="text-[11px] text-white/35">Payments secured by <span className="text-blue-400 font-bold">Razorpay</span>. 256-bit SSL encrypted.</p>
                </div>
              )}
              <div className="flex gap-3">
                <button onClick={() => setStep('schedule')} className="flex-1 py-3.5 rounded-2xl glass text-white/40 text-sm font-semibold">Back</button>
                <motion.button whileTap={{ scale: 0.98 }} onClick={() => payMethod !== 'cod' ? setStep('upi_pay') : setStep('confirm')}
                  className="flex-1 bg-gradient-to-r from-orange-500 to-orange-600 text-black font-bold py-3.5 rounded-2xl transition-all">
                  {payMethod !== 'cod' ? 'Pay Now' : 'Review Order'}
                </motion.button>
              </div>
            </motion.div>
          )}

          {step === 'upi_pay' && (
            <motion.div key="upi_pay" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} transition={{ duration: 0.35 }}>
              <UPIPaymentFlow amount={total} bookingId={`BK${Date.now().toString().slice(-4)}`}
                onComplete={() => { setBooked(true); setTimeout(() => router.push('/bookings'), 2000); }} onBack={() => setStep('payment')} />
            </motion.div>
          )}

          {step === 'confirm' && (
            <motion.div key="confirm" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} transition={{ duration: 0.35 }} className="space-y-4">
              <div className="glass rounded-2xl p-4 space-y-3">
                <p className="text-sm font-bold text-white/70">Order Summary</p>
                {[
                  { label: 'Service', value: service.name }, { label: 'Date', value: date }, { label: 'Time', value: time },
                  { label: 'Address', value: address }, { label: 'Payment', value: 'Cash on Delivery' }, { label: 'Total', value: `₹${total}` },
                ].map(({ label, value }) => (
                  <div key={label} className="flex justify-between gap-4">
                    <span className="text-[11px] text-white/30 shrink-0">{label}</span>
                    <span className={`text-[11px] text-right font-medium ${label === 'Total' ? 'text-orange-500 font-black text-sm' : 'text-white/70'}`}>{value}</span>
                  </div>
                ))}
              </div>
              <div className="flex items-center gap-2.5 glass rounded-xl p-3.5">
                <Shield size={14} className="text-green-400 shrink-0" />
                <p className="text-[11px] text-white/35">30-day service warranty included with this booking</p>
              </div>
              <div className="flex gap-3">
                <button onClick={() => setStep('payment')} className="flex-1 py-3.5 rounded-2xl glass text-white/40 text-sm font-semibold">Back</button>
                <motion.button whileTap={{ scale: 0.98 }} onClick={handleBooking} disabled={loading}
                  className="flex-1 bg-gradient-to-r from-orange-500 to-orange-600 disabled:opacity-60 text-black font-bold py-3.5 rounded-2xl transition-all flex items-center justify-center gap-2">
                  {loading ? <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full" /> : 'Confirm Booking'}
                </motion.button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <BottomNav />
    </motion.div>
  );
}

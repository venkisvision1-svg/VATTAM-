'use client';

import { useParams } from 'next/navigation';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowLeft, MapPin, Clock, Phone, Star, CheckCircle, MessageCircle, Wind, Shield } from 'lucide-react';
import { STATUS_CONFIG } from '@/lib/services-data';

const MOCK_BOOKING = {
  id: 'B001',
  service: 'AC Service',
  icon: Wind,
  iconColor: 'text-blue-400',
  iconBg: 'bg-blue-500/10',
  iconBorder: 'border-blue-500/15',
  status: 'confirmed' as const,
  date: 'May 28, 2026',
  time: '10:00 AM',
  address: '45, Anna Nagar, Chennai - 600040',
  notes: 'Please bring gas refill equipment',
  amount: 646,
  provider: { name: 'Rajan Electricals', rating: 4.8, phone: '+91 98765 43210', jobs: 127 },
  timeline: [
    { step: 'Booking Placed', done: true, time: 'May 26, 9:30 AM' },
    { step: 'Provider Confirmed', done: true, time: 'May 26, 10:15 AM' },
    { step: 'Technician On Way', done: false, time: 'May 28, 9:45 AM' },
    { step: 'Service In Progress', done: false, time: '' },
    { step: 'Completed', done: false, time: '' },
  ],
};

export default function BookingDetailPage() {
  const params = useParams();
  const statusCfg = STATUS_CONFIG[MOCK_BOOKING.status];
  const Icon = MOCK_BOOKING.icon;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }} className="min-h-screen bg-[#070707] pb-10">
      <div className="sticky top-0 z-40 glass-strong border-b border-white/[0.04]">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center gap-3">
          <Link href="/bookings" className="p-1.5 rounded-xl hover:bg-white/5 transition-colors">
            <ArrowLeft size={18} className="text-white/60" />
          </Link>
          <h1 className="text-sm font-bold text-white flex-1">Booking #{params.id}</h1>
          <span className={`text-[9px] font-bold px-2.5 py-1 rounded-lg border ${statusCfg.color} ${statusCfg.bg} ${statusCfg.border}`}>
            {statusCfg.label}
          </span>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 pt-4 space-y-4">
        {/* Service Info */}
        <div className="glass-orange rounded-2xl p-4">
          <div className="flex items-center gap-3.5 mb-3">
            <div className={`w-14 h-14 rounded-2xl ${MOCK_BOOKING.iconBg} border ${MOCK_BOOKING.iconBorder} flex items-center justify-center`}>
              <Icon size={24} className={MOCK_BOOKING.iconColor} />
            </div>
            <div>
              <h2 className="text-lg font-black text-white">{MOCK_BOOKING.service}</h2>
              <p className="text-[10px] text-white/25 font-medium">Booking #{MOCK_BOOKING.id}</p>
            </div>
          </div>
          <div className="space-y-2 pt-3 border-t border-orange-500/10">
            {[
              { icon: Clock, value: `${MOCK_BOOKING.date} at ${MOCK_BOOKING.time}` },
              { icon: MapPin, value: MOCK_BOOKING.address },
            ].map(({ icon: ItemIcon, value }) => (
              <div key={value} className="flex items-start gap-2.5 text-white/40">
                <ItemIcon size={13} className="shrink-0 mt-0.5 text-orange-500/50" />
                <span className="text-[11px]">{value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Provider Card */}
        <div className="glass rounded-2xl p-4 glass-card">
          <p className="text-[10px] font-bold text-white/25 mb-3 uppercase tracking-wider">Assigned Provider</p>
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-500/20 to-orange-600/5 border border-orange-500/20 flex items-center justify-center shrink-0">
              <span className="text-lg font-black text-orange-500">{MOCK_BOOKING.provider.name[0]}</span>
            </div>
            <div className="flex-1">
              <p className="font-bold text-white">{MOCK_BOOKING.provider.name}</p>
              <div className="flex items-center gap-1.5 mt-0.5">
                <Star size={11} className="text-orange-500 fill-orange-500" />
                <span className="text-[11px] text-white/35">{MOCK_BOOKING.provider.rating} • {MOCK_BOOKING.provider.jobs} jobs</span>
              </div>
            </div>
            <div className="flex gap-2">
              <a href={`tel:${MOCK_BOOKING.provider.phone}`} className="w-9 h-9 rounded-xl bg-green-500/10 border border-green-500/20 flex items-center justify-center hover:bg-green-500/20 transition-colors">
                <Phone size={14} className="text-green-400" />
              </a>
              <a href={`https://wa.me/${MOCK_BOOKING.provider.phone.replace(/\D/g, '')}`} className="w-9 h-9 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center hover:bg-blue-500/20 transition-colors">
                <MessageCircle size={14} className="text-blue-400" />
              </a>
            </div>
          </div>
        </div>

        {/* Timeline */}
        <div className="glass rounded-2xl p-4 glass-card">
          <p className="text-[10px] font-bold text-white/25 mb-4 uppercase tracking-wider">Booking Timeline</p>
          <div className="relative">
            <div className="absolute left-[18px] top-2 bottom-2 w-px bg-white/[0.04]" />
            <div className="space-y-4">
              {MOCK_BOOKING.timeline.map(({ step, done, time }, i) => {
                const isNext = !done && i === MOCK_BOOKING.timeline.findIndex(t => !t.done);
                return (
                  <div key={i} className="flex items-start gap-3.5">
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 z-10 border transition-all ${
                      done ? 'bg-green-500/15 border-green-500/25' :
                      isNext ? 'bg-orange-500/15 border-orange-500/25' :
                      'bg-white/[0.02] border-white/[0.06]'
                    }`}>
                      {done ? <CheckCircle size={14} className="text-green-400" /> :
                       isNext ? <div className="w-2.5 h-2.5 rounded-full bg-orange-500 pulse-glow" /> :
                       <div className="w-2 h-2 rounded-full bg-white/10" />}
                    </div>
                    <div className="pt-1.5">
                      <p className={`text-sm font-medium ${done ? 'text-white/80' : isNext ? 'text-orange-400' : 'text-white/20'}`}>{step}</p>
                      {time && <p className="text-[10px] text-white/15 mt-0.5">{time}</p>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Payment */}
        <div className="glass rounded-2xl p-4 glass-card">
          <p className="text-[10px] font-bold text-white/25 mb-3 uppercase tracking-wider">Payment Summary</p>
          <div className="space-y-2 mb-3">
            {[
              { label: 'Service Charge', value: '₹499' },
              { label: 'Platform Fee', value: '₹49' },
              { label: 'Tax (GST)', value: '₹98' },
            ].map(({ label, value }) => (
              <div key={label} className="flex justify-between text-xs text-white/30">
                <span>{label}</span><span>{value}</span>
              </div>
            ))}
          </div>
          <div className="flex justify-between items-center pt-2.5 border-t border-white/[0.04]">
            <span className="text-sm font-bold text-white/70">Total Paid</span>
            <span className="text-xl font-black text-gradient">₹{MOCK_BOOKING.amount}</span>
          </div>
        </div>

        {/* Warranty badge */}
        <div className="flex items-center gap-2.5 glass rounded-xl p-3.5">
          <Shield size={14} className="text-green-400 shrink-0" />
          <p className="text-[11px] text-white/35">This booking is covered by VATTAM&apos;s 30-day service warranty</p>
        </div>
      </div>
    </motion.div>
  );
}

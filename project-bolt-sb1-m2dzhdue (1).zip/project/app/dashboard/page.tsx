'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { CalendarCheck, Star, TrendingUp, ChevronRight, Wind, Zap, Droplets, ArrowUpRight, Heart, Bell, Settings, CreditCard, Gift, Clock } from 'lucide-react';
import Header from '@/components/Header';
import BottomNav from '@/components/BottomNav';
import { STATUS_CONFIG } from '@/lib/services-data';

const RECENT_BOOKINGS = [
  { id: 'B001', service: 'AC Service', status: 'confirmed' as const, date: '28 May', amount: 646, icon: Wind, color: 'text-blue-400', bg: 'bg-blue-500/10' },
  { id: 'B002', service: 'Electrician', status: 'completed' as const, date: '20 May', amount: 460, icon: Zap, color: 'text-yellow-400', bg: 'bg-yellow-500/10' },
  { id: 'B003', service: 'Plumbing', status: 'in_progress' as const, date: '26 May', amount: 520, icon: Droplets, color: 'text-cyan-400', bg: 'bg-cyan-500/10' },
];

const QUICK_ACTIONS = [
  { label: 'Track Order', icon: TrendingUp, href: '/bookings', color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/15' },
  { label: 'Favourites', icon: Heart, href: '/profile', color: 'text-pink-400', bg: 'bg-pink-500/10', border: 'border-pink-500/15' },
  { label: 'Alerts', icon: Bell, href: '/profile', color: 'text-yellow-400', bg: 'bg-yellow-500/10', border: 'border-yellow-500/15' },
  { label: 'Payments', icon: CreditCard, href: '/profile', color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/15' },
];

export default function DashboardPage() {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }} className="min-h-screen bg-[#070707] pb-24">
      <Header />

      <div className="px-4 pt-4 max-w-lg mx-auto">
        {/* Welcome Banner */}
        <div className="relative glass-orange rounded-2xl p-5 mb-5 overflow-hidden">
          <div className="absolute top-0 right-0 w-48 h-48 bg-orange-500/10 rounded-full blur-[60px] -translate-y-1/2 translate-x-1/4" />
          <div className="relative z-10 flex items-start justify-between">
            <div>
              <p className="text-white/35 text-xs font-medium mb-1">Vanakkam,</p>
              <h2 className="text-xl font-black text-white">Suresh Kumar</h2>
              <div className="flex items-center gap-1.5 mt-1.5">
                <Star size={11} className="text-orange-500 fill-orange-500" />
                <span className="text-[11px] text-white/35 font-medium">Chennai, Tamil Nadu</span>
              </div>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-orange-500/25 to-orange-600/10 border border-orange-500/25 flex items-center justify-center">
              <span className="text-xl font-black text-orange-500">S</span>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-2.5 mb-5">
          {[
            { label: 'Total Bookings', value: '12', sub: '+3 this month', color: 'text-orange-500' },
            { label: 'Completed', value: '9', sub: '75% success', color: 'text-green-400' },
            { label: 'Spent', value: '₹4.2K', sub: 'Lifetime', color: 'text-blue-400' },
          ].map(({ label, value, sub, color }) => (
            <div key={label} className="glass rounded-2xl p-3 glass-card">
              <p className={`text-lg font-black ${color}`}>{value}</p>
              <p className="text-[10px] text-white/45 font-semibold mt-0.5">{label}</p>
              <p className="text-[9px] text-white/20 mt-0.5">{sub}</p>
            </div>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="mb-5">
          <div className="relative mb-3">
            <h3 className="text-sm font-bold text-white/70">Quick Actions</h3>
            <div className="absolute -bottom-1 left-0 w-6 h-0.5 bg-orange-500/50 rounded-full" />
          </div>
          <div className="grid grid-cols-4 gap-3">
            {QUICK_ACTIONS.map(({ label, icon: Icon, href, color, bg, border }) => (
              <Link key={label} href={href} className="flex flex-col items-center gap-2 group">
                <div className={`w-12 h-12 rounded-2xl ${bg} border ${border} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                  <Icon size={20} className={color} />
                </div>
                <span className="text-[10px] text-white/35 text-center leading-tight font-medium">{label}</span>
              </Link>
            ))}
          </div>
        </div>

        {/* Recent Bookings */}
        <div className="mb-5">
          <div className="flex items-center justify-between mb-3">
            <div className="relative">
              <h3 className="text-sm font-bold text-white/70">Recent Bookings</h3>
              <div className="absolute -bottom-1 left-0 w-6 h-0.5 bg-orange-500/50 rounded-full" />
            </div>
            <Link href="/bookings" className="text-[11px] text-orange-500 flex items-center gap-1 hover:text-orange-400 font-semibold">
              View All <ChevronRight size={12} />
            </Link>
          </div>
          <div className="space-y-2">
            {RECENT_BOOKINGS.map(({ id, service, status, date, amount, icon: Icon, color, bg }) => {
              const statusCfg = STATUS_CONFIG[status];
              return (
                <div key={id} className="flex items-center gap-3 glass rounded-xl p-3.5 glass-card">
                  <div className={`w-10 h-10 rounded-xl ${bg} flex items-center justify-center shrink-0`}>
                    <Icon size={16} className={color} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-white/90 truncate">{service}</p>
                    <p className="text-[10px] text-white/25 font-medium">{date} • ₹{amount}</p>
                  </div>
                  <span className={`text-[9px] font-bold px-2 py-1 rounded-lg border shrink-0 ${statusCfg.color} ${statusCfg.bg} ${statusCfg.border}`}>
                    {statusCfg.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Offer Banner */}
        <div className="relative rounded-2xl p-5 overflow-hidden glow-orange mb-5">
          <div className="absolute inset-0 bg-gradient-to-r from-orange-600/90 to-orange-500/90" />
          <div className="absolute inset-0 dot-pattern opacity-20" />
          <div className="absolute top-0 right-0 w-28 h-28 bg-white/10 rounded-full blur-2xl -translate-y-1/2 translate-x-1/3" />
          <div className="relative z-10">
            <div className="flex items-center gap-1.5 mb-1">
              <Gift size={12} className="text-black/70" />
              <p className="text-[10px] font-bold text-black/70 uppercase tracking-wider">Limited Offer</p>
            </div>
            <p className="text-black font-black text-xl leading-tight">20% OFF on AC Service</p>
            <p className="text-black/60 text-xs mt-1 mb-3">Use code: <span className="font-bold">VATTAM20</span></p>
            <Link href="/book/ac-service" className="inline-flex items-center gap-1.5 bg-black/90 text-white text-xs font-bold px-4 py-2 rounded-xl hover:bg-black transition-colors">
              Book Now <ArrowUpRight size={12} />
            </Link>
          </div>
        </div>

        {/* Settings */}
        <Link href="/profile" className="flex items-center gap-3 glass rounded-2xl p-4 glass-card">
          <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center">
            <Settings size={18} className="text-white/40" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-semibold text-white/80">Account Settings</p>
            <p className="text-xs text-white/25">Manage profile &amp; preferences</p>
          </div>
          <ChevronRight size={16} className="text-white/20" />
        </Link>
      </div>

      <BottomNav />
    </motion.div>
  );
}

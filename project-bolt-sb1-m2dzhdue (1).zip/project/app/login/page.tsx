'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { Phone, ArrowRight, ArrowLeft, CheckCircle, Shield, Smartphone } from 'lucide-react';

type Step = 'phone' | 'otp' | 'success';

export default function LoginPage() {
  const router = useRouter();
  const [step, setStep] = useState<Step>('phone');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handlePhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (phone.length !== 10) {
      setError('Enter a valid 10-digit mobile number');
      return;
    }
    setLoading(true);
    setError('');
    await new Promise(r => setTimeout(r, 1200));
    setLoading(false);
    setStep('otp');
  };

  const handleOtpChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    const newOtp = [...otp];
    newOtp[index] = value.slice(-1);
    setOtp(newOtp);
    if (value && index < 5) {
      document.getElementById(`otp-${index + 1}`)?.focus();
    }
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      document.getElementById(`otp-${index - 1}`)?.focus();
    }
  };

  const handleOtpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const code = otp.join('');
    if (code.length !== 6) {
      setError('Enter the 6-digit OTP');
      return;
    }
    setLoading(true);
    setError('');
    await new Promise(r => setTimeout(r, 1200));
    setLoading(false);
    setStep('success');
    setTimeout(() => router.push('/'), 1500);
  };

  return (
    <div className="min-h-screen bg-[#070707] flex flex-col items-center justify-center px-4 relative">
      <motion.div
        animate={{ scale: [1, 1.1, 1], opacity: [0.05, 0.08, 0.05] }}
        transition={{ duration: 4, repeat: Infinity }}
        className="fixed top-1/4 left-1/2 -translate-x-1/2 w-80 h-80 bg-orange-500 rounded-full blur-[100px] pointer-events-none"
      />
      <div className="fixed bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-orange-500/3 to-transparent pointer-events-none" />

      <div className="w-full max-w-sm relative z-10">
        {/* Logo */}
        <motion.div
          initial={{ y: -30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
          className="text-center mb-8"
        >
          <motion.div
            whileHover={{ scale: 1.05, rotate: 5 }}
            className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-500 to-orange-600 glow-orange mb-4"
          >
            <span className="text-2xl font-black text-black">V</span>
          </motion.div>
          <h1 className="text-3xl font-black">
            <span className="text-white">VAT</span>
            <span className="text-orange-500">TAM</span>
          </h1>
          <p className="text-white/30 text-xs mt-1.5 font-medium tracking-wide">Home Services Made Easy</p>
        </motion.div>

        <AnimatePresence mode="wait">
          {step === 'phone' && (
            <motion.div key="phone" initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -40 }} transition={{ duration: 0.4 }}>
              <div className="glass rounded-3xl p-6">
                <h2 className="text-xl font-black text-white mb-1">Welcome Back</h2>
                <p className="text-white/35 text-sm mb-6 leading-relaxed">Enter your mobile number to login or create an account</p>

                <form onSubmit={handlePhoneSubmit} className="space-y-4">
                  <div>
                    <label className="text-[11px] font-semibold text-white/50 mb-2 block uppercase tracking-wider">Mobile Number</label>
                    <div className="flex">
                      <div className="flex items-center gap-2 glass rounded-l-xl px-3.5 shrink-0 border-r-0 rounded-r-none">
                        <Smartphone size={14} className="text-orange-500" />
                        <span className="text-sm text-white/50 font-medium">+91</span>
                      </div>
                      <input
                        type="tel"
                        inputMode="numeric"
                        maxLength={10}
                        placeholder="9876543210"
                        value={phone}
                        onChange={e => { setPhone(e.target.value.replace(/\D/g, '')); setError(''); }}
                        className="flex-1 glass rounded-r-xl px-4 py-3.5 text-white text-sm placeholder-white/20 focus:outline-none focus:border-orange-500/50 transition-all duration-300 rounded-l-none"
                      />
                    </div>
                    {error && <motion.p initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} className="text-red-400 text-xs mt-2 font-medium">{error}</motion.p>}
                  </div>

                  <motion.button
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                    type="submit"
                    disabled={loading}
                    className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-400 hover:to-orange-500 disabled:opacity-50 text-black font-bold py-3.5 rounded-2xl transition-all duration-300 glow-orange-sm"
                  >
                    {loading ? (
                      <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full" />
                    ) : (
                      <>Send OTP <ArrowRight size={16} /></>
                    )}
                  </motion.button>
                </form>
              </div>

              <div className="flex items-center gap-2.5 mt-4 glass rounded-xl p-3.5">
                <Shield size={14} className="text-green-400 shrink-0" />
                <p className="text-[11px] text-white/40 leading-relaxed">Your number is safe and never shared with third parties. OTP based secure login.</p>
              </div>

              <p className="text-center text-[11px] text-white/20 mt-5 leading-relaxed">
                By continuing, you agree to our <span className="text-orange-400/70 cursor-pointer">Terms</span> and <span className="text-orange-400/70 cursor-pointer">Privacy Policy</span>
              </p>
            </motion.div>
          )}

          {step === 'otp' && (
            <motion.div key="otp" initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -40 }} transition={{ duration: 0.4 }}>
              <div className="glass rounded-3xl p-6">
                <motion.button whileTap={{ scale: 0.95 }} onClick={() => { setStep('phone'); setError(''); setOtp(['','','','','','']); }} className="flex items-center gap-1.5 text-white/35 hover:text-white/60 text-sm mb-4 transition-colors font-medium">
                  <ArrowLeft size={14} /> Back
                </motion.button>

                <div className="flex items-center gap-3.5 mb-5">
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-orange-500/20 to-orange-600/5 border border-orange-500/20 flex items-center justify-center">
                    <Phone size={18} className="text-orange-500" />
                  </div>
                  <div>
                    <h2 className="text-xl font-black text-white">Verify OTP</h2>
                    <p className="text-white/35 text-xs mt-0.5">Sent to +91 {phone}</p>
                  </div>
                </div>

                <form onSubmit={handleOtpSubmit} className="space-y-5">
                  <div className="flex gap-2.5 justify-between">
                    {otp.map((digit, i) => (
                      <motion.input
                        key={i}
                        id={`otp-${i}`}
                        type="tel"
                        inputMode="numeric"
                        maxLength={1}
                        value={digit}
                        onChange={e => { handleOtpChange(i, e.target.value); setError(''); }}
                        onKeyDown={e => handleOtpKeyDown(i, e)}
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        transition={{ delay: i * 0.05 }}
                        className={`w-11 h-13 text-center text-xl font-bold glass rounded-xl text-white focus:outline-none transition-all duration-300 ${
                          digit ? 'border-orange-500/50 text-orange-400' : 'focus:border-orange-500/40'
                        }`}
                        autoFocus={i === 0}
                      />
                    ))}
                  </div>

                  {error && <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-red-400 text-xs font-medium">{error}</motion.p>}

                  <motion.button
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                    type="submit"
                    disabled={loading}
                    className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 to-orange-600 disabled:opacity-50 text-black font-bold py-3.5 rounded-2xl transition-all duration-300"
                  >
                    {loading ? (
                      <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full" />
                    ) : (
                      <>Verify &amp; Login <ArrowRight size={16} /></>
                    )}
                  </motion.button>

                  <p className="text-center text-[11px] text-white/30">
                    Didn&apos;t receive OTP?{' '}
                    <button type="button" onClick={() => setStep('phone')} className="text-orange-500 hover:text-orange-400 font-semibold">Resend</button>
                  </p>
                </form>
              </div>
            </motion.div>
          )}

          {step === 'success' && (
            <motion.div
              key="success"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: 'spring', stiffness: 200, damping: 15 }}
              className="text-center"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
                className="w-20 h-20 rounded-3xl bg-green-500/15 border border-green-500/25 flex items-center justify-center mx-auto mb-5 glow-green"
              >
                <CheckCircle size={36} className="text-green-500" />
              </motion.div>
              <h2 className="text-2xl font-black text-white mb-2">Welcome!</h2>
              <p className="text-white/40 text-sm">Login successful. Redirecting...</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

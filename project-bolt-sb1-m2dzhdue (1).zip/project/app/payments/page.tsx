'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowLeft, CreditCard, QrCode, Smartphone, CheckCircle, Clock, XCircle } from 'lucide-react';
import Header from '@/components/Header';
import BottomNav from '@/components/BottomNav';
import { MOCK_UPI_PAYMENTS, PAYMENT_STATUS_CONFIG } from '@/lib/mock-data';

export default function PaymentsPage() {
  const customerPayments = MOCK_UPI_PAYMENTS.filter(p => p.customerId === 'c1');

  const totalSpent = customerPayments.filter(p => p.status === 'success').reduce((a, p) => a + p.amount, 0);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }} className="min-h-screen bg-[#070707] pb-24">
      <Header title="Payment History" showLocation={false} showNotification={false} />

      <div className="px-4 pt-4 max-w-lg mx-auto">
        {/* Summary */}
        <div className="glass-orange rounded-2xl p-5 mb-5">
          <p className="text-[10px] text-white/35 font-semibold uppercase tracking-wider">Total Spent</p>
          <p className="text-3xl font-black text-gradient mt-1">₹{totalSpent.toLocaleString()}</p>
          <div className="flex items-center gap-4 mt-3 pt-3 border-t border-orange-500/15">
            <div>
              <p className="text-sm font-bold text-green-400">{customerPayments.filter(p => p.status === 'success').length}</p>
              <p className="text-[9px] text-white/25 uppercase">Successful</p>
            </div>
            <div>
              <p className="text-sm font-bold text-yellow-400">{customerPayments.filter(p => p.status === 'pending').length}</p>
              <p className="text-[9px] text-white/25 uppercase">Pending</p>
            </div>
          </div>
        </div>

        {/* Payment History */}
        <div className="relative mb-4">
          <h3 className="text-sm font-bold text-white/70">Transaction History</h3>
          <div className="absolute -bottom-1 left-0 w-6 h-0.5 bg-orange-500/50 rounded-full" />
        </div>

        <div className="space-y-2.5">
          {customerPayments.map(p => {
            const cfg = PAYMENT_STATUS_CONFIG[p.status];
            return (
              <div key={p.id} className="glass rounded-2xl p-4 glass-card">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/15 flex items-center justify-center shrink-0">
                      {p.paymentMethod === 'qr' ? <QrCode size={16} className="text-orange-400" /> :
                       p.paymentMethod === 'upi' ? <Smartphone size={16} className="text-orange-400" /> :
                       <CreditCard size={16} className="text-orange-400" />}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-white">₹{p.amount}</p>
                      <p className="text-[10px] text-white/25">{p.paymentMethod.toUpperCase()} • #{p.bookingId}</p>
                    </div>
                  </div>
                  <span className={`text-[9px] font-bold px-2 py-0.5 rounded-lg border ${cfg.color} ${cfg.bg} ${cfg.border}`}>{cfg.label}</span>
                </div>
                {p.transactionId && (
                  <div className="pt-2 border-t border-white/[0.04]">
                    <p className="text-[10px] text-white/15 font-mono">TXN: {p.transactionId}</p>
                  </div>
                )}
                <div className="flex items-center justify-between pt-2 border-t border-white/[0.04]">
                  <p className="text-[10px] text-white/15">{p.createdAt}</p>
                  <p className="text-[10px] text-white/20">{p.upiId}</p>
                </div>
              </div>
            );
          })}
        </div>

        {customerPayments.length === 0 && (
          <div className="text-center py-12">
            <CreditCard size={32} className="text-white/8 mx-auto mb-2" />
            <p className="text-white/20 text-sm">No payment history yet</p>
          </div>
        )}
      </div>

      <BottomNav />
    </motion.div>
  );
}

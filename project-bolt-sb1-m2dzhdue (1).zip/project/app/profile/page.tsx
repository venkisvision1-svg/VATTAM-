'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { User, Phone, MapPin, ChevronRight, LogOut, Shield, Bell, CreditCard, HelpCircle, Star, Settings, BadgeCheck, Heart, FileText, Gift } from 'lucide-react';
import Header from '@/components/Header';
import BottomNav from '@/components/BottomNav';

const MENU_ITEMS = [
  {
    section: 'Account',
    items: [
      { icon: User, label: 'Edit Profile', href: '/profile/edit', color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/15' },
      { icon: Bell, label: 'Notifications', href: '/profile/notifications', color: 'text-yellow-400', bg: 'bg-yellow-500/10', border: 'border-yellow-500/15' },
      { icon: CreditCard, label: 'Payment Methods', href: '/profile/payments', color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/15' },
    ],
  },
  {
    section: 'Services',
    items: [
      { icon: Star, label: 'My Reviews', href: '/profile/reviews', color: 'text-orange-400', bg: 'bg-orange-500/10', border: 'border-orange-500/15' },
      { icon: Shield, label: 'Service Warranty', href: '/profile/warranty', color: 'text-teal-400', bg: 'bg-teal-500/10', border: 'border-teal-500/15' },
      { icon: Heart, label: 'Saved Providers', href: '/profile/saved', color: 'text-pink-400', bg: 'bg-pink-500/10', border: 'border-pink-500/15' },
      { icon: FileText, label: 'Invoices', href: '/profile/invoices', color: 'text-white/50', bg: 'bg-white/5', border: 'border-white/8' },
    ],
  },
  {
    section: 'Support',
    items: [
      { icon: HelpCircle, label: 'Help & Support', href: '/support', color: 'text-white/40', bg: 'bg-white/5', border: 'border-white/8' },
      { icon: Gift, label: 'Refer & Earn', href: '/refer', color: 'text-orange-400', bg: 'bg-orange-500/10', border: 'border-orange-500/15' },
      { icon: Settings, label: 'Settings', href: '/profile/settings', color: 'text-white/40', bg: 'bg-white/5', border: 'border-white/8' },
    ],
  },
];

export default function ProfilePage() {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }} className="min-h-screen bg-[#070707] pb-24">
      <Header title="Profile" showLocation={false} showNotification={false} />

      <div className="px-4 pt-4 max-w-lg mx-auto">
        {/* Profile Card */}
        <div className="glass-orange rounded-2xl p-5 mb-5">
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-500/30 to-orange-600/10 border border-orange-500/25 flex items-center justify-center">
                <span className="text-2xl font-black text-orange-500">S</span>
              </div>
              <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-green-500/20 border border-green-500/30 flex items-center justify-center">
                <BadgeCheck size={10} className="text-green-400" />
              </div>
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-white">Suresh Kumar</h2>
              </div>
              <div className="flex items-center gap-1.5 text-white/30 mt-0.5">
                <Phone size={11} />
                <span className="text-[11px]">+91 98765 43210</span>
              </div>
              <div className="flex items-center gap-1.5 text-white/30 mt-0.5">
                <MapPin size={11} />
                <span className="text-[11px]">Chennai, Tamil Nadu</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-orange-500/15">
            {[
              { label: 'Bookings', value: '12' },
              { label: 'Reviews', value: '8' },
              { label: 'Points', value: '340' },
            ].map(({ label, value }) => (
              <div key={label} className="text-center">
                <p className="text-lg font-black text-orange-500">{value}</p>
                <p className="text-[9px] text-white/30 uppercase tracking-wider font-semibold">{label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Menu Sections */}
        <div className="space-y-5">
          {MENU_ITEMS.map(({ section, items }) => (
            <div key={section}>
              <p className="text-[10px] font-bold text-white/20 uppercase tracking-widest mb-2 px-1">{section}</p>
              <div className="glass rounded-2xl overflow-hidden">
                {items.map(({ icon: Icon, label, href, color, bg, border }, i) => (
                  <Link
                    key={label}
                    href={href}
                    className={`flex items-center gap-3.5 px-4 py-3.5 hover:bg-white/3 transition-colors group ${i > 0 ? 'border-t border-white/[0.03]' : ''}`}
                  >
                    <div className={`w-9 h-9 rounded-xl ${bg} border ${border} flex items-center justify-center shrink-0`}>
                      <Icon size={16} className={color} />
                    </div>
                    <span className="flex-1 text-sm text-white/65 group-hover:text-white/90 transition-colors font-medium">{label}</span>
                    <ChevronRight size={14} className="text-white/15 group-hover:text-white/30 transition-colors" />
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Provider CTA */}
        <div className="mt-5 glass-orange rounded-2xl p-4">
          <p className="text-sm font-bold text-white mb-1">Become a Provider</p>
          <p className="text-[11px] text-white/35 mb-3 leading-relaxed">Register as a service professional and earn more across Tamil Nadu</p>
          <Link href="/provider/register" className="inline-flex items-center gap-2 bg-gradient-to-r from-orange-500 to-orange-600 text-black font-bold px-4 py-2 rounded-xl text-sm hover:from-orange-400 hover:to-orange-500 transition-all">
            Join Now <ChevronRight size={14} />
          </Link>
        </div>

        {/* Logout */}
        <button className="w-full mt-4 flex items-center justify-center gap-2 py-3.5 rounded-2xl border border-red-500/15 text-red-400/70 text-sm font-semibold hover:bg-red-500/5 transition-colors mb-2">
          <LogOut size={16} /> Sign Out
        </button>

        <p className="text-center text-[9px] text-white/10 pb-2 font-medium tracking-wider uppercase">
          VATTAM v1.0 • Made with care in Tamil Nadu
        </p>
      </div>

      <BottomNav />
    </motion.div>
  );
}

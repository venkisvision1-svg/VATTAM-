'use client';

import Link from 'next/link';
import { useState } from 'react';
import { motion } from 'framer-motion';
import type { LucideIcon } from 'lucide-react';
import { ArrowLeft, TrendingUp, Clock, CheckCircle, Star, MapPin, Phone, Wind, Zap, Droplets, ChevronRight, DollarSign, Calendar, QrCode, BarChart3, Eye, Navigation } from 'lucide-react';
import { STATUS_CONFIG } from '@/lib/services-data';

const UPCOMING_JOBS = [
  { id: 'J001', service: 'AC Service', icon: Wind as LucideIcon, iconColor: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/15', customer: 'Priya Ramesh', phone: '+91 98765 43210', address: '45, Anna Nagar, Chennai', time: 'Today, 10:00 AM', amount: 646, status: 'confirmed' as const },
  { id: 'J002', service: 'Electrician', icon: Zap as LucideIcon, iconColor: 'text-yellow-400', bg: 'bg-yellow-500/10', border: 'border-yellow-500/15', customer: 'Ramesh Babu', phone: '+91 87654 32109', address: '12, T Nagar, Chennai', time: 'Today, 02:00 PM', amount: 460, status: 'pending' as const },
  { id: 'J003', service: 'Plumbing', icon: Droplets as LucideIcon, iconColor: 'text-cyan-400', bg: 'bg-cyan-500/10', border: 'border-cyan-500/15', customer: 'Meena Devi', phone: '+91 76543 21098', address: '78, Velachery, Chennai', time: 'Tomorrow, 09:00 AM', amount: 520, status: 'confirmed' as const },
];

export default function ProviderDashboardPage() {
  const [isAvailable, setIsAvailable] = useState(true);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }} className="min-h-screen bg-[#070707] pb-10">
      {/* Header */}
      <div className="sticky top-0 z-40 glass-strong border-b border-white/[0.04]">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/" className="p-1.5 rounded-xl hover:bg-white/5 transition-colors">
              <ArrowLeft size={18} className="text-white/60" />
            </Link>
            <div>
              <h1 className="text-base font-bold text-white">Provider Dashboard</h1>
              <p className="text-[10px] text-white/30 font-medium">Rajan Electricals</p>
            </div>
          </div>
          <button
            onClick={() => setIsAvailable(!isAvailable)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-[11px] font-bold border transition-all duration-300 ${
              isAvailable
                ? 'bg-green-500/10 border-green-500/25 text-green-400'
                : 'glass text-white/35'
            }`}
          >
            <div className={`w-2 h-2 rounded-full ${isAvailable ? 'bg-green-400 pulse-glow' : 'bg-white/20'}`} />
            {isAvailable ? 'Online' : 'Offline'}
          </button>
        </div>
      </div>

      <div className="px-4 pt-4 max-w-lg mx-auto">
        {/* Profile Card */}
        <div className="glass-orange rounded-2xl p-5 mb-5">
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-500/25 to-orange-600/10 border border-orange-500/25 flex items-center justify-center">
              <span className="text-2xl font-black text-orange-500">R</span>
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-white">Rajan Electricals</h2>
              </div>
              <div className="flex items-center gap-1 mt-1.5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} size={11} className={i < 4 ? 'text-orange-500 fill-orange-500' : 'text-white/15'} />
                ))}
                <span className="text-[11px] text-white/35 ml-1.5 font-medium">4.8 (127 reviews)</span>
              </div>
              <div className="flex items-center gap-1.5 text-white/30 mt-1">
                <MapPin size={11} />
                <span className="text-[11px]">Chennai, Tamil Nadu</span>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-2.5 mb-5">
          {[
            { label: "Today's Jobs", value: '3', sub: '2 pending, 1 done', icon: Calendar, color: 'text-orange-500', bg: 'bg-orange-500/10', border: 'border-orange-500/15' },
            { label: "Today's Earnings", value: '₹1,626', sub: '+₹460 pending', icon: DollarSign, color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/15' },
            { label: 'This Month', value: '38', sub: 'Jobs completed', icon: CheckCircle, color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/15' },
            { label: 'Monthly Income', value: '₹24K', sub: '+12% from last', icon: TrendingUp, color: 'text-teal-400', bg: 'bg-teal-500/10', border: 'border-teal-500/15' },
          ].map(({ label, value, sub, icon: Icon, color, bg, border }) => (
            <div key={label} className="glass rounded-2xl p-4 glass-card">
              <div className={`w-9 h-9 rounded-xl ${bg} border ${border} flex items-center justify-center mb-2`}>
                <Icon size={16} className={color} />
              </div>
              <p className={`text-xl font-black ${color}`}>{value}</p>
              <p className="text-[11px] text-white/50 font-semibold mt-0.5">{label}</p>
              <p className="text-[9px] text-white/20 mt-0.5">{sub}</p>
            </div>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-3 gap-2.5 mb-5">
          {[
            { icon: QrCode, label: 'QR Profile', href: '/provider/qr/rajan-electricals', color: 'text-orange-400', bg: 'bg-orange-500/10', border: 'border-orange-500/15' },
            { icon: BarChart3, label: 'Analytics', href: '#', color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/15' },
            { icon: Eye, label: 'Reviews', href: '#', color: 'text-yellow-400', bg: 'bg-yellow-500/10', border: 'border-yellow-500/15' },
          ].map(({ icon: Icon, label, href, color, bg, border }) => (
            <Link key={label} href={href} className="glass rounded-2xl p-3 glass-card text-center group">
              <div className={`w-9 h-9 rounded-xl ${bg} border ${border} flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-transform duration-300`}>
                <Icon size={16} className={color} />
              </div>
              <p className="text-[11px] text-white/50 font-semibold">{label}</p>
            </Link>
          ))}
        </div>

        {/* Upcoming Jobs */}
        <div className="mb-5">
          <div className="flex items-center justify-between mb-3">
            <div className="relative">
              <h3 className="text-sm font-bold text-white/70">Upcoming Jobs</h3>
              <div className="absolute -bottom-1 left-0 w-6 h-0.5 bg-orange-500/50 rounded-full" />
            </div>
            <span className="text-[10px] font-bold text-orange-500 bg-orange-500/10 border border-orange-500/20 px-2.5 py-0.5 rounded-full">{UPCOMING_JOBS.length} jobs</span>
          </div>

          <div className="space-y-3">
            {UPCOMING_JOBS.map(job => {
              const statusCfg = STATUS_CONFIG[job.status];
              return (
                <div key={job.id} className="glass rounded-2xl p-4 glass-card relative overflow-hidden">
                  {job.status === 'confirmed' && (
                    <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-green-500/30 to-transparent" />
                  )}
                  <div className="flex items-start gap-3.5 mb-3">
                    <div className={`w-11 h-11 rounded-xl ${job.bg} border ${job.border} flex items-center justify-center shrink-0`}>
                      <job.icon size={18} className={job.iconColor} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-bold text-white">{job.service}</p>
                        <span className={`text-[9px] font-bold px-2 py-0.5 rounded-lg border ${statusCfg.color} ${statusCfg.bg} ${statusCfg.border}`}>
                          {statusCfg.label}
                        </span>
                      </div>
                      <p className="text-[11px] text-white/35 font-medium">{job.customer}</p>
                    </div>
                  </div>

                  <div className="space-y-1.5 mb-3">
                    {[
                      { icon: Clock, text: job.time },
                      { icon: MapPin, text: job.address },
                      { icon: Phone, text: job.phone },
                    ].map(({ icon: ItemIcon, text }) => (
                      <div key={text} className="flex items-center gap-2 text-white/30">
                        <ItemIcon size={11} />
                        <span className="text-[11px]">{text}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center justify-between pt-2.5 border-t border-white/[0.04]">
                    <span className="text-base font-black text-gradient">₹{job.amount}</span>
                    <div className="flex gap-2">
                      {job.status === 'pending' && (
                        <button className="px-3 py-1.5 rounded-xl bg-green-500/10 border border-green-500/25 text-green-400 text-[11px] font-bold hover:bg-green-500/20 transition-colors">
                          Accept
                        </button>
                      )}
                      {job.status === 'confirmed' && (
                        <button className="px-3 py-1.5 rounded-xl bg-orange-500/10 border border-orange-500/25 text-orange-400 text-[11px] font-bold hover:bg-orange-500/20 transition-colors flex items-center gap-1">
                          <Navigation size={10} /> Navigate
                        </button>
                      )}
                      <button className="px-3 py-1.5 rounded-xl glass text-white/50 text-[11px] font-bold hover:text-white/70 transition-colors">
                        View
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Earnings Chart */}
        <div className="glass rounded-2xl p-4 glass-card mb-5">
          <div className="flex items-center justify-between mb-4">
            <div className="relative">
              <h3 className="text-sm font-bold text-white/70">Weekly Earnings</h3>
              <div className="absolute -bottom-1 left-0 w-6 h-0.5 bg-orange-500/50 rounded-full" />
            </div>
            <span className="text-[10px] text-white/25 font-medium">This week</span>
          </div>
          <div className="flex items-end gap-1.5 h-28">
            {[40, 65, 45, 80, 60, 95, 70].map((h, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-1.5">
                <div
                  className="w-full rounded-t-xl bg-gradient-to-t from-orange-500/40 to-orange-500 transition-all duration-500 hover:from-orange-500/60 hover:to-orange-400"
                  style={{ height: `${h}%` }}
                />
                <span className="text-[8px] text-white/20 font-medium">
                  {['M', 'T', 'W', 'T', 'F', 'S', 'S'][i]}
                </span>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-between mt-3 pt-2 border-t border-white/[0.04]">
            <span className="text-[11px] text-white/30 font-medium">Total this week</span>
            <span className="text-sm font-black text-gradient">₹3,800</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

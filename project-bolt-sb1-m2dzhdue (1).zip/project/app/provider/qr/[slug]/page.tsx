'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { Star, MapPin, Phone, Wind, Zap, Camera, CheckCircle, Share2, ArrowRight, BadgeCheck, Clock, MessageCircle, Shield, Award } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

const MOCK_PROVIDER = {
  name: 'Rajan Electricals',
  tagline: 'Expert AC & Electrical Services Since 2018',
  bio: '8+ years of experience in AC servicing, electrical installations, and appliance repair. Serving Chennai and nearby areas with quality and reliability.',
  rating: 4.8,
  totalJobs: 127,
  city: 'Chennai, Tamil Nadu',
  phone: '+91 98765 43210',
  isVerified: true,
  isAvailable: true,
  memberSince: '2022',
  responseTime: '< 30 mins',
  services: [
    { name: 'AC Service', price: 499, icon: Wind as LucideIcon, color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/15' },
    { name: 'Electrician', price: 349, icon: Zap as LucideIcon, color: 'text-yellow-400', bg: 'bg-yellow-500/10', border: 'border-yellow-500/15' },
    { name: 'CCTV Installation', price: 1499, icon: Camera as LucideIcon, color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/15' },
  ],
  reviews: [
    { name: 'Priya R.', rating: 5, comment: 'Excellent work! Very professional and on time.', date: 'May 2026' },
    { name: 'Suresh K.', rating: 5, comment: 'Fixed my AC perfectly. Highly recommended!', date: 'Apr 2026' },
    { name: 'Meena D.', rating: 4, comment: 'Good service, fair pricing.', date: 'Apr 2026' },
  ],
  badges: ['Top Rated', 'Fast Response', '100+ Jobs'],
};

export default function QRProfilePage() {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }} className="min-h-screen bg-[#070707]">
      {/* Hero */}
      <div className="relative bg-gradient-to-b from-[#1c0e00] via-[#0f0800] to-[#070707] pt-10 pb-6 px-4">
        <div className="absolute inset-0 dot-pattern opacity-20" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-80 bg-orange-500/10 rounded-full blur-[80px]" />

        {/* VATTAM Badge */}
        <div className="flex justify-center mb-6 relative z-10">
          <Link href="/" className="flex items-center gap-2 text-white/30 hover:text-white/50 transition-colors">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center">
              <span className="text-[10px] font-black text-black">V</span>
            </div>
            <span className="text-xs font-bold tracking-widest">VATTAM</span>
          </Link>
        </div>

        <div className="max-w-sm mx-auto text-center relative z-10">
          {/* Avatar */}
          <div className="relative inline-block mb-4">
            <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-orange-500/30 to-orange-600/10 border-2 border-orange-500/30 flex items-center justify-center glow-orange">
              <span className="text-4xl font-black text-orange-500">{MOCK_PROVIDER.name[0]}</span>
            </div>
            {MOCK_PROVIDER.isVerified && (
              <div className="absolute -bottom-1.5 -right-1.5 w-8 h-8 rounded-xl bg-[#070707] border border-orange-500/30 flex items-center justify-center">
                <BadgeCheck size={16} className="text-orange-500" />
              </div>
            )}
          </div>

          <h1 className="text-2xl font-black text-white mb-1">{MOCK_PROVIDER.name}</h1>
          <p className="text-white/40 text-sm mb-3">{MOCK_PROVIDER.tagline}</p>

          {/* Status */}
          <div className="flex items-center justify-center gap-2 mb-3.5">
            <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-bold ${
              MOCK_PROVIDER.isAvailable ? 'bg-green-500/10 border-green-500/25 text-green-400' : 'glass text-white/30'
            }`}>
              <div className={`w-1.5 h-1.5 rounded-full ${MOCK_PROVIDER.isAvailable ? 'bg-green-400 pulse-glow' : 'bg-white/20'}`} />
              {MOCK_PROVIDER.isAvailable ? 'Available Now' : 'Offline'}
            </div>
          </div>

          {/* Badges */}
          <div className="flex items-center justify-center gap-1.5 mb-4 flex-wrap">
            {MOCK_PROVIDER.badges.map(badge => (
              <span key={badge} className="text-[9px] font-bold text-orange-500 bg-orange-500/8 border border-orange-500/20 px-2 py-0.5 rounded-full">{badge}</span>
            ))}
          </div>

          {/* Stats */}
          <div className="flex items-center justify-center gap-5 mb-5">
            {[
              { label: 'Rating', value: MOCK_PROVIDER.rating, icon: Star },
              { label: 'Jobs Done', value: `${MOCK_PROVIDER.totalJobs}+` },
              { label: 'Response', value: MOCK_PROVIDER.responseTime },
            ].map(({ label, value, icon: Icon }) => (
              <div key={label} className="text-center">
                <div className="flex items-center justify-center gap-1">
                  {Icon && <Icon size={13} className="text-orange-500 fill-orange-500" />}
                  <span className="text-lg font-black text-white">{value}</span>
                </div>
                <p className="text-[9px] text-white/25 uppercase tracking-wider font-semibold mt-0.5">{label}</p>
              </div>
            ))}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2.5 justify-center">
            <a href={`tel:${MOCK_PROVIDER.phone}`} className="flex items-center gap-2 glass rounded-xl px-4 py-2.5 text-sm font-semibold text-white/70 hover:border-orange-500/20 transition-all">
              <Phone size={14} className="text-orange-500" /> Call
            </a>
            <a href={`https://wa.me/${MOCK_PROVIDER.phone.replace(/\D/g, '')}`} target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2 bg-green-500/10 border border-green-500/25 text-green-400 font-semibold px-4 py-2.5 rounded-xl text-sm hover:bg-green-500/20 transition-colors">
              <MessageCircle size={14} /> WhatsApp
            </a>
            <button className="flex items-center gap-2 glass rounded-xl px-3 py-2.5 text-white/40 hover:border-orange-500/20 transition-all">
              <Share2 size={14} />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-sm mx-auto px-4 pb-10">
        {/* Info */}
        <div className="glass rounded-2xl p-4 glass-card mb-4">
          <div className="space-y-2.5">
            {[
              { icon: MapPin, label: MOCK_PROVIDER.city },
              { icon: Clock, label: `Member since ${MOCK_PROVIDER.memberSince}` },
              { icon: Shield, label: 'VATTAM Verified Professional' },
            ].map(({ icon: Icon, label }) => (
              <div key={label} className="flex items-center gap-2.5">
                <Icon size={13} className="text-orange-500/50" />
                <span className="text-[11px] text-white/45">{label}</span>
              </div>
            ))}
          </div>
          <p className="text-[11px] text-white/30 mt-3 leading-relaxed">{MOCK_PROVIDER.bio}</p>
        </div>

        {/* Services */}
        <div className="mb-4">
          <div className="relative mb-3">
            <h2 className="text-sm font-bold text-white/70">Services Offered</h2>
            <div className="absolute -bottom-1 left-0 w-6 h-0.5 bg-orange-500/50 rounded-full" />
          </div>
          <div className="space-y-2">
            {MOCK_PROVIDER.services.map(({ name, price, icon: Icon, color, bg, border }) => (
              <div key={name} className="flex items-center gap-3.5 glass rounded-xl p-3.5 glass-card">
                <div className={`w-10 h-10 rounded-xl ${bg} border ${border} flex items-center justify-center shrink-0`}>
                  <Icon size={18} className={color} />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-white/90">{name}</p>
                  <div className="flex items-center gap-1 mt-0.5">
                    <CheckCircle size={10} className="text-green-400" />
                    <span className="text-[10px] text-white/25">30-day warranty</span>
                  </div>
                </div>
                <span className="text-sm font-bold text-gradient">₹{price}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Reviews */}
        <div className="mb-6">
          <div className="relative mb-3">
            <h2 className="text-sm font-bold text-white/70">Customer Reviews</h2>
            <div className="absolute -bottom-1 left-0 w-6 h-0.5 bg-orange-500/50 rounded-full" />
          </div>
          <div className="space-y-2.5">
            {MOCK_PROVIDER.reviews.map((review, i) => (
              <div key={i} className="glass rounded-xl p-3.5 glass-card">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-orange-500/15 border border-orange-500/15 flex items-center justify-center">
                      <span className="text-[10px] font-bold text-orange-500">{review.name[0]}</span>
                    </div>
                    <span className="text-sm font-semibold text-white/80">{review.name}</span>
                  </div>
                  <span className="text-[9px] text-white/20">{review.date}</span>
                </div>
                <div className="flex gap-0.5 mb-1.5">
                  {Array.from({ length: review.rating }).map((_, j) => (
                    <Star key={j} size={10} className="text-orange-500 fill-orange-500" />
                  ))}
                </div>
                <p className="text-[11px] text-white/40 leading-relaxed">{review.comment}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <Link href="/book/ac-service"
          className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-400 hover:to-orange-500 text-black font-black py-4 rounded-2xl text-base transition-all duration-300 glow-orange">
          Book This Provider <ArrowRight size={18} strokeWidth={2.5} />
        </Link>

        <p className="text-center text-[9px] text-white/10 mt-4 font-medium tracking-wider uppercase">
          Powered by <span className="text-orange-500/50">VATTAM</span> • Verified Professional
        </p>
      </div>
    </motion.div>
  );
}

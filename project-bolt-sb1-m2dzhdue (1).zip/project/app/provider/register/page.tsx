'use client';

import { useState } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, ArrowRight, CheckCircle, Upload, Briefcase } from 'lucide-react';
import { SERVICES } from '@/lib/services-data';

type Step = 'basic' | 'skills' | 'docs' | 'done';

export default function ProviderRegisterPage() {
  const [step, setStep] = useState<Step>('basic');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [bio, setBio] = useState('');
  const [selected, setSelected] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const toggleService = (id: string) => {
    setSelected(prev => prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]);
  };

  const handleSubmit = async () => {
    setLoading(true);
    await new Promise(r => setTimeout(r, 1500));
    setLoading(false);
    setStep('done');
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }} className="min-h-screen bg-[#070707] pb-10">
      <div className="sticky top-0 z-40 glass-strong border-b border-white/[0.04]">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center gap-3">
          <Link href="/" className="p-1.5 rounded-xl hover:bg-white/5">
            <ArrowLeft size={18} className="text-white/60" />
          </Link>
          <div className="flex items-center gap-2">
            <Briefcase size={16} className="text-orange-500" />
            <h1 className="text-sm font-bold text-white">Join as Provider</h1>
          </div>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 pt-6">
        {step !== 'done' && (
          <div className="flex gap-1.5 mb-6">
            {(['basic', 'skills', 'docs'] as Step[]).map((s, i) => (
              <div key={s} className={`flex-1 h-1 rounded-full transition-all duration-500 ${
                ['basic', 'skills', 'docs'].indexOf(step) >= i ? 'bg-gradient-to-r from-orange-500 to-orange-600' : 'bg-white/8'
              }`} />
            ))}
          </div>
        )}

        {step === 'basic' && (
          <div className="space-y-4 slide-up">
            <div>
              <h2 className="text-xl font-black text-white mb-1">Basic Info</h2>
              <p className="text-white/30 text-sm mb-5">Tell us about yourself</p>
            </div>

            {[
              { label: 'Full Name', value: name, set: setName, placeholder: 'Your full name' },
              { label: 'Mobile Number', value: phone, set: setPhone, placeholder: '+91 98765 43210' },
              { label: 'City', value: city, set: setCity, placeholder: 'Chennai, Coimbatore...' },
            ].map(({ label, value, set, placeholder }) => (
              <div key={label}>
                <label className="text-[11px] font-semibold text-white/40 mb-2 block uppercase tracking-wider">{label}</label>
                <input type="text" placeholder={placeholder} value={value} onChange={e => set(e.target.value)}
                  className="w-full glass rounded-2xl px-4 py-3.5 text-sm text-white placeholder-white/20 focus:outline-none focus:border-orange-500/40 transition-all" />
              </div>
            ))}

            <div>
              <label className="text-[11px] font-semibold text-white/40 mb-2 block uppercase tracking-wider">Bio / About You</label>
              <textarea placeholder="Years of experience, specialization, etc." value={bio} onChange={e => setBio(e.target.value)} rows={3}
                className="w-full glass rounded-2xl px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-orange-500/40 transition-all resize-none" />
            </div>

            <button onClick={() => name && phone && setStep('skills')} disabled={!name || !phone}
              className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 to-orange-600 disabled:opacity-40 text-black font-bold py-3.5 rounded-2xl transition-all">
              Continue <ArrowRight size={16} />
            </button>
          </div>
        )}

        {step === 'skills' && (
          <div className="space-y-4 slide-up">
            <div>
              <h2 className="text-xl font-black text-white mb-1">Your Skills</h2>
              <p className="text-white/30 text-sm mb-5">Select the services you provide</p>
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              {SERVICES.map(service => {
                const isSelected = selected.includes(service.id);
                return (
                  <button key={service.id} onClick={() => toggleService(service.id)}
                    className={`p-4 rounded-2xl text-left transition-all duration-300 ${
                      isSelected ? 'glass-orange' : 'glass glass-card hover:border-orange-500/20'
                    }`}>
                    <div className="flex items-start justify-between mb-2">
                      <p className={`text-sm font-bold ${isSelected ? 'text-orange-400' : 'text-white/70'}`}>{service.name}</p>
                      {isSelected && <CheckCircle size={14} className="text-orange-500 shrink-0" />}
                    </div>
                    <p className="text-[11px] text-white/30">{service.description}</p>
                    <p className="text-[11px] text-orange-500/60 mt-1 font-medium">from ₹{service.basePrice}</p>
                  </button>
                );
              })}
            </div>
            <div className="flex gap-3">
              <button onClick={() => setStep('basic')} className="flex-1 py-3.5 rounded-2xl glass text-white/40 text-sm font-semibold">Back</button>
              <button onClick={() => selected.length > 0 && setStep('docs')} disabled={selected.length === 0}
                className="flex-1 bg-gradient-to-r from-orange-500 to-orange-600 disabled:opacity-40 text-black font-bold py-3.5 rounded-2xl transition-all">Continue</button>
            </div>
          </div>
        )}

        {step === 'docs' && (
          <div className="space-y-4 slide-up">
            <div>
              <h2 className="text-xl font-black text-white mb-1">Verification</h2>
              <p className="text-white/30 text-sm mb-5">Upload documents for verification</p>
            </div>
            {['Aadhaar Card', 'Skill Certificate', 'Profile Photo'].map(doc => (
              <div key={doc} className="glass rounded-2xl p-5 text-center hover:border-orange-500/20 transition-colors cursor-pointer group border-dashed">
                <Upload size={24} className="text-white/15 group-hover:text-orange-500/40 mx-auto mb-2 transition-colors" />
                <p className="text-sm font-semibold text-white/50">{doc}</p>
                <p className="text-[10px] text-white/20 mt-0.5">Click to upload (JPG, PNG, PDF)</p>
              </div>
            ))}
            <div className="flex gap-3">
              <button onClick={() => setStep('skills')} className="flex-1 py-3.5 rounded-2xl glass text-white/40 text-sm font-semibold">Back</button>
              <button onClick={handleSubmit} disabled={loading}
                className="flex-1 bg-gradient-to-r from-orange-500 to-orange-600 disabled:opacity-60 text-black font-bold py-3.5 rounded-2xl transition-all flex items-center justify-center gap-2">
                {loading ? <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin" /> : 'Submit Application'}
              </button>
            </div>
          </div>
        )}

        {step === 'done' && (
          <div className="fade-in text-center pt-10">
            <div className="w-24 h-24 rounded-3xl bg-green-500/15 border border-green-500/25 flex items-center justify-center mx-auto mb-5">
              <CheckCircle size={44} className="text-green-500" />
            </div>
            <h2 className="text-2xl font-black text-white mb-2">Application Submitted!</h2>
            <p className="text-white/35 text-sm mb-6 leading-relaxed">Our team will verify your documents within 24-48 hours. You&apos;ll receive an SMS once approved.</p>
            <Link href="/" className="inline-flex items-center gap-2 bg-gradient-to-r from-orange-500 to-orange-600 text-black font-bold px-6 py-3 rounded-2xl hover:from-orange-400 hover:to-orange-500 transition-all">
              Go to Home <ArrowRight size={16} />
            </Link>
          </div>
        )}
      </div>
    </motion.div>
  );
}

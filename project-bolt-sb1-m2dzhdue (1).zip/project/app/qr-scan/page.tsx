'use client';

import { useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowLeft, QrCode, Camera, ScanLine, Smartphone, Wifi } from 'lucide-react';
import Header from '@/components/Header';
import BottomNav from '@/components/BottomNav';

export default function QRScanPage() {
  const [scanning, setScanning] = useState(false);
  const [scanned, setScanned] = useState(false);

  const handleScan = () => {
    setScanning(true);
    setTimeout(() => {
      setScanning(false);
      setScanned(true);
    }, 2000);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }} className="min-h-screen bg-[#070707] pb-24">
      <Header title="Scan QR Code" showLocation={false} showNotification={false} />

      <div className="px-4 pt-6 max-w-lg mx-auto">
        {/* Scanner Area */}
        <div className="relative glass rounded-3xl p-6 mb-5">
          {/* Scan Frame */}
          <div className="relative w-56 h-56 mx-auto mb-5">
            {/* Corner markers */}
            <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-orange-500 rounded-tl-xl" />
            <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-orange-500 rounded-tr-xl" />
            <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-orange-500 rounded-bl-xl" />
            <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-orange-500 rounded-br-xl" />

            {/* Scanning animation */}
            {scanning && (
              <div className="absolute inset-x-8 h-0.5 bg-gradient-to-r from-transparent via-orange-500 to-transparent animate-bounce" style={{ animationDuration: '1.5s' }} />
            )}

            {/* Center icon */}
            <div className="absolute inset-0 flex items-center justify-center">
              {scanning ? (
                <div className="flex flex-col items-center gap-3">
                  <ScanLine size={32} className="text-orange-500 animate-pulse" />
                  <p className="text-xs text-orange-400 font-semibold">Scanning...</p>
                </div>
              ) : scanned ? (
                <div className="flex flex-col items-center gap-3 scale-in">
                  <div className="w-14 h-14 rounded-2xl bg-green-500/15 border border-green-500/25 flex items-center justify-center">
                    <QrCode size={24} className="text-green-400" />
                  </div>
                  <p className="text-xs text-green-400 font-bold">QR Detected!</p>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-3">
                  <QrCode size={36} className="text-white/15" />
                  <p className="text-xs text-white/25 font-medium">Position QR code here</p>
                </div>
              )}
            </div>

            {/* Dot pattern overlay */}
            <div className="absolute inset-0 dot-pattern opacity-10" />
          </div>

          {/* Scan Button */}
          {!scanning && !scanned && (
            <button
              onClick={handleScan}
              className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 to-orange-600 text-black font-bold py-3.5 rounded-2xl transition-all duration-300 glow-orange-sm hover:glow-orange"
            >
              <Camera size={18} />
              Start Scanning
            </button>
          )}

          {scanned && (
            <Link
              href="/provider/qr/rajan-electricals"
              className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 to-orange-600 text-black font-bold py-3.5 rounded-2xl transition-all duration-300 glow-orange-sm"
            >
              View Provider Profile
            </Link>
          )}

          {scanning && (
            <button
              onClick={() => setScanning(false)}
              className="w-full flex items-center justify-center gap-2 glass text-white/50 font-bold py-3.5 rounded-2xl"
            >
              Cancel
            </button>
          )}
        </div>

        {/* Instructions */}
        <div className="space-y-3 mb-5">
          <h3 className="text-sm font-bold text-white/70 relative">
            How to scan
            <div className="absolute -bottom-1 left-0 w-6 h-0.5 bg-orange-500/50 rounded-full" />
          </h3>
          {[
            { icon: Smartphone, title: 'Point your camera', desc: 'Hold your phone steady over the QR code' },
            { icon: ScanLine, title: 'Auto-detect', desc: 'The scanner will automatically detect the code' },
            { icon: Wifi, title: 'No internet needed', desc: 'Works offline for provider lookup' },
          ].map(({ icon: Icon, title, desc }) => (
            <div key={title} className="flex items-start gap-3.5 glass rounded-xl p-3.5 glass-card">
              <div className="w-9 h-9 rounded-xl bg-orange-500/10 border border-orange-500/15 flex items-center justify-center shrink-0">
                <Icon size={16} className="text-orange-500" />
              </div>
              <div>
                <p className="text-sm font-semibold text-white/80">{title}</p>
                <p className="text-[11px] text-white/30 mt-0.5">{desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Or enter code manually */}
        <div className="glass rounded-2xl p-4 glass-card">
          <p className="text-sm font-semibold text-white/70 mb-2">Or enter provider code</p>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="e.g. rajan-electricals"
              className="flex-1 glass rounded-xl px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-orange-500/40 transition-all"
            />
            <Link
              href="/provider/qr/rajan-electricals"
              className="px-4 py-3 rounded-xl bg-gradient-to-r from-orange-500 to-orange-600 text-black font-bold text-sm shrink-0"
            >
              Go
            </Link>
          </div>
        </div>
      </div>

      <BottomNav />
    </motion.div>
  );
}

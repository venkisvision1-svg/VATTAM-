'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, SlidersHorizontal } from 'lucide-react';
import Header from '@/components/Header';
import BottomNav from '@/components/BottomNav';
import ServiceCard from '@/components/ServiceCard';
import { SERVICES } from '@/lib/services-data';

const CATEGORIES = ['All', 'Appliance', 'Home', 'Security'];

const stagger = { animate: { transition: { staggerChildren: 0.06 } } };
const fadeUp = { initial: { opacity: 0, y: 15 }, animate: { opacity: 1, y: 0, transition: { duration: 0.4 } } };

export default function ServicesPage() {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');

  const filtered = SERVICES.filter(s => {
    const matchSearch = s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.description.toLowerCase().includes(search.toLowerCase());
    const matchCat = category === 'All' || s.category.toLowerCase() === category.toLowerCase();
    return matchSearch && matchCat;
  });

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }} className="min-h-screen bg-[#070707] pb-24">
      <Header title="Services" showLocation={false} />

      <div className="px-4 pt-4 max-w-lg mx-auto">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="relative mb-4">
          <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/25" />
          <input type="text" placeholder="Search services..." value={search} onChange={e => setSearch(e.target.value)}
            className="w-full glass rounded-2xl pl-11 pr-4 py-3.5 text-sm text-white placeholder-white/25 focus:outline-none focus:border-orange-500/40 transition-all duration-300" />
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="flex gap-2 overflow-x-auto pb-2 mb-4 scrollbar-hide">
          {CATEGORIES.map(cat => (
            <motion.button key={cat} whileTap={{ scale: 0.95 }} onClick={() => setCategory(cat)}
              className={`shrink-0 px-4 py-2 rounded-xl text-xs font-bold transition-all duration-300 ${
                category === cat ? 'bg-gradient-to-r from-orange-500 to-orange-600 text-black glow-orange-sm' : 'glass text-white/50 hover:border-orange-500/20'}`}>
              {cat}
            </motion.button>
          ))}
        </motion.div>

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }} className="flex items-center justify-between mb-4">
          <p className="text-xs text-white/30 font-medium">{filtered.length} services available</p>
          <button className="flex items-center gap-1.5 text-xs text-white/40 hover:text-orange-400 transition-colors font-medium">
            <SlidersHorizontal size={12} /> Filter
          </button>
        </motion.div>

        {filtered.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-white/20 font-semibold text-lg">No services found</p>
            <p className="text-white/10 text-sm mt-1">Try a different search or category</p>
          </div>
        ) : (
          <motion.div variants={stagger} initial="initial" animate="animate" className="grid grid-cols-2 gap-3">
            {filtered.map(service => (
              <motion.div key={service.id} variants={fadeUp}>
                <ServiceCard {...service} />
              </motion.div>
            ))}
          </motion.div>
        )}
      </div>

      <BottomNav />
    </motion.div>
  );
}

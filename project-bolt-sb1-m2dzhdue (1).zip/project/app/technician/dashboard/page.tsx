'use client';

import { useState } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, CheckCircle, XCircle, Clock, MapPin, Phone, Camera, Upload, DollarSign, Calendar, TrendingUp, Package, Star, Eye } from 'lucide-react';
import { STATUS_CONFIG } from '@/lib/services-data';
import { MOCK_BOOKINGS, MOCK_TECHNICIAN_EARNINGS, MOCK_TECHNICIANS, TECHNICIAN_STATUS_CONFIG, PAYMENT_STATUS_CONFIG } from '@/lib/mock-data';

type TechView = 'jobs' | 'earnings' | 'profile';

const ASSIGNED_JOBS = MOCK_BOOKINGS.filter(b => b.technicianId === 't1');

export default function TechnicianDashboardPage() {
  const [view, setView] = useState<TechView>('jobs');
  const [uploadModal, setUploadModal] = useState<string | null>(null);

  const totalEarned = MOCK_TECHNICIAN_EARNINGS.filter(e => e.technicianId === 't1').reduce((a, e) => a + e.netAmount, 0);
  const pendingPayout = MOCK_TECHNICIAN_EARNINGS.filter(e => e.technicianId === 't1' && e.status === 'pending').reduce((a, e) => a + e.netAmount, 0);

  const handleAccept = (bookingId: string) => {
    console.log(`Accepted booking ${bookingId}`);
  };

  const handleReject = (bookingId: string) => {
    console.log(`Rejected booking ${bookingId}`);
  };

  const handleStatusUpdate = (bookingId: string, status: string) => {
    console.log(`Booking ${bookingId} -> ${status}`);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }} className="min-h-screen bg-[#070707] pb-10">
      {/* Header */}
      <div className="sticky top-0 z-40 glass-strong border-b border-white/[0.04]">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/" className="p-1.5 rounded-xl hover:bg-white/5"><ArrowLeft size={18} className="text-white/60" /></Link>
            <div>
              <h1 className="text-base font-bold text-white">Technician Panel</h1>
              <p className="text-[10px] text-white/30 font-medium">Rajan Kumar • TECH-001</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 bg-green-500/10 border border-green-500/25 px-2.5 py-1 rounded-xl">
            <div className="w-1.5 h-1.5 bg-green-400 rounded-full pulse-glow" />
            <span className="text-[10px] text-green-400 font-bold">ONLINE</span>
          </div>
        </div>

        {/* View Tabs */}
        <div className="max-w-lg mx-auto px-4 pb-3">
          <div className="flex gap-1 glass rounded-xl p-1">
            {[
              { key: 'jobs' as TechView, label: 'Jobs', icon: Calendar },
              { key: 'earnings' as TechView, label: 'Earnings', icon: DollarSign },
              { key: 'profile' as TechView, label: 'Profile', icon: Star },
            ].map(({ key, label, icon: Icon }) => (
              <button key={key} onClick={() => setView(key)}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-bold transition-all ${view === key ? 'bg-gradient-to-r from-orange-500 to-orange-600 text-black' : 'text-white/30'}`}>
                <Icon size={12} />{label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 pt-4">
        {/* JOBS VIEW */}
        {view === 'jobs' && (
          <div className="space-y-4 slide-up">
            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-2.5">
              {[
                { label: 'Pending', value: ASSIGNED_JOBS.filter(j => j.technicianStatus === 'pending').length, color: 'text-yellow-400' },
                { label: 'In Progress', value: ASSIGNED_JOBS.filter(j => j.technicianStatus === 'in_progress').length, color: 'text-orange-400' },
                { label: 'Completed', value: ASSIGNED_JOBS.filter(j => j.technicianStatus === 'completed').length, color: 'text-green-400' },
              ].map(({ label, value, color }) => (
                <div key={label} className="glass rounded-2xl p-3 text-center glass-card">
                  <p className={`text-lg font-black ${color}`}>{value}</p>
                  <p className="text-[8px] text-white/25 uppercase tracking-wider font-semibold">{label}</p>
                </div>
              ))}
            </div>

            {/* Job Cards */}
            <div className="space-y-3">
              {ASSIGNED_JOBS.map(job => {
                const sCfg = STATUS_CONFIG[job.status];
                return (
                  <div key={job.id} className="glass rounded-2xl p-4 glass-card relative overflow-hidden">
                    {job.technicianStatus === 'in_progress' && (
                      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-orange-500/40 to-transparent" />
                    )}

                    <div className="flex items-start justify-between gap-2 mb-3">
                      <div>
                        <p className="text-sm font-bold text-white">{job.serviceName}</p>
                        <p className="text-[10px] text-white/25 mt-0.5">#{job.id} • {job.scheduledDate} at {job.scheduledTime}</p>
                      </div>
                      <span className={`text-[9px] font-bold px-2 py-0.5 rounded-lg border ${sCfg.color} ${sCfg.bg} ${sCfg.border}`}>
                        {sCfg.label}
                      </span>
                    </div>

                    <div className="space-y-1.5 mb-3">
                      <div className="flex items-center gap-2 text-white/30"><Clock size={11} /><span className="text-[11px]">{job.scheduledDate} at {job.scheduledTime}</span></div>
                      <div className="flex items-center gap-2 text-white/30"><MapPin size={11} /><span className="text-[11px]">{job.address}</span></div>
                      <div className="flex items-center gap-2 text-white/30"><Phone size={11} /><span className="text-[11px]">{job.customerPhone}</span></div>
                    </div>

                    {job.notes && (
                      <div className="bg-white/[0.02] rounded-lg p-2.5 mb-3">
                        <p className="text-[10px] text-white/25 font-semibold mb-0.5">Notes:</p>
                        <p className="text-[11px] text-white/40">{job.notes}</p>
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-2.5 border-t border-white/[0.04]">
                      <span className="text-base font-black text-gradient">₹{job.totalAmount}</span>
                      <div className="flex gap-2">
                        {job.technicianStatus === 'pending' && (
                          <>
                            <button onClick={() => handleAccept(job.id)} className="px-3 py-1.5 rounded-xl bg-green-500/10 border border-green-500/25 text-green-400 text-[11px] font-bold hover:bg-green-500/20 transition-colors flex items-center gap-1">
                              <CheckCircle size={10} /> Accept
                            </button>
                            <button onClick={() => handleReject(job.id)} className="px-3 py-1.5 rounded-xl bg-red-500/10 border border-red-500/25 text-red-400 text-[11px] font-bold hover:bg-red-500/20 transition-colors flex items-center gap-1">
                              <XCircle size={10} /> Reject
                            </button>
                          </>
                        )}
                        {job.technicianStatus === 'accepted' && (
                          <button onClick={() => handleStatusUpdate(job.id, 'in_progress')} className="px-3 py-1.5 rounded-xl bg-orange-500/10 border border-orange-500/25 text-orange-400 text-[11px] font-bold hover:bg-orange-500/20 transition-colors">
                            Start Work
                          </button>
                        )}
                        {job.technicianStatus === 'in_progress' && (
                          <button onClick={() => setUploadModal(job.id)} className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-orange-500 to-orange-600 text-black text-[11px] font-bold flex items-center gap-1">
                            <Upload size={10} /> Complete & Upload
                          </button>
                        )}
                        {job.technicianStatus === 'completed' && (
                          <span className="text-[10px] text-green-400 font-bold flex items-center gap-1"><CheckCircle size={10} /> Done</span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {ASSIGNED_JOBS.length === 0 && (
              <div className="text-center py-12"><Package size={32} className="text-white/8 mx-auto mb-2" /><p className="text-white/20 text-sm">No assigned jobs yet</p></div>
            )}

            {/* Upload Modal */}
            {uploadModal && (
              <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setUploadModal(null)}>
                <div className="glass rounded-2xl p-6 w-full max-w-sm scale-in" onClick={e => e.stopPropagation()}>
                  <h3 className="text-lg font-bold text-white mb-2">Upload Work Photo</h3>
                  <p className="text-xs text-white/30 mb-4">Take a photo of the completed work to verify the job</p>
                  <div className="glass rounded-2xl p-8 text-center mb-4 border-dashed cursor-pointer group">
                    <Camera size={32} className="text-white/10 group-hover:text-orange-500/40 mx-auto mb-2 transition-colors" />
                    <p className="text-sm font-semibold text-white/40">Tap to take photo</p>
                    <p className="text-[10px] text-white/20 mt-0.5">Or upload from gallery</p>
                  </div>
                  <div className="flex gap-3">
                    <button onClick={() => setUploadModal(null)} className="flex-1 py-3 rounded-xl glass text-white/40 text-sm font-semibold">Cancel</button>
                    <button onClick={() => { handleStatusUpdate(uploadModal, 'completed'); setUploadModal(null); }}
                      className="flex-1 bg-gradient-to-r from-orange-500 to-orange-600 text-black font-bold py-3 rounded-xl text-sm">
                      Submit
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* EARNINGS VIEW */}
        {view === 'earnings' && (
          <div className="space-y-4 slide-up">
            <div className="glass-orange rounded-2xl p-5">
              <p className="text-xs text-white/40 font-medium mb-1">Total Earnings</p>
              <p className="text-3xl font-black text-gradient">₹{totalEarned.toLocaleString()}</p>
              <div className="flex items-center gap-4 mt-3 pt-3 border-t border-orange-500/15">
                <div>
                  <p className="text-sm font-bold text-yellow-400">₹{pendingPayout.toLocaleString()}</p>
                  <p className="text-[9px] text-white/25 uppercase">Pending</p>
                </div>
                <div>
                  <p className="text-sm font-bold text-green-400">₹{(totalEarned - pendingPayout).toLocaleString()}</p>
                  <p className="text-[9px] text-white/25 uppercase">Paid</p>
                </div>
              </div>
            </div>

            {/* Weekly Chart */}
            <div className="glass rounded-2xl p-4 glass-card">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-bold text-white/70">Weekly Earnings</h3>
                <span className="text-[10px] text-white/25">This week</span>
              </div>
              <div className="flex items-end gap-1.5 h-28">
                {[1200, 800, 1500, 600, 1800, 2100, 900].map((h, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1.5">
                    <div className="w-full rounded-t-xl bg-gradient-to-t from-orange-500/40 to-orange-500 hover:from-orange-500/60 hover:to-orange-400 transition-all" style={{ height: `${(h / 2100) * 100}%` }} />
                    <span className="text-[8px] text-white/20 font-medium">{['M', 'T', 'W', 'T', 'F', 'S', 'S'][i]}</span>
                  </div>
                ))}
              </div>
              <div className="text-center mt-2">
                <p className="text-sm font-black text-gradient">₹8,900</p>
                <p className="text-[9px] text-white/20">This week</p>
              </div>
            </div>

            {/* Earnings History */}
            <div>
              <h3 className="text-sm font-bold text-white/70 mb-3 relative">Payout History<div className="absolute -bottom-1 left-0 w-6 h-0.5 bg-orange-500/50 rounded-full" /></h3>
              <div className="space-y-2">
                {MOCK_TECHNICIAN_EARNINGS.filter(e => e.technicianId === 't1').map(earning => {
                  const pCfg = earning.status === 'paid' ? PAYMENT_STATUS_CONFIG.success : PAYMENT_STATUS_CONFIG.pending;
                  return (
                    <div key={earning.id} className="glass rounded-xl p-3.5 glass-card flex items-center gap-3.5">
                      <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${earning.status === 'paid' ? 'bg-green-500/10 border border-green-500/15' : 'bg-yellow-500/10 border border-yellow-500/15'}`}>
                        <DollarSign size={16} className={earning.status === 'paid' ? 'text-green-400' : 'text-yellow-400'} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-white">Booking #{earning.bookingId}</p>
                        <p className="text-[10px] text-white/20">Fee: ₹{earning.platformFee} • Net: ₹{earning.netAmount}</p>
                      </div>
                      <span className={`text-[9px] font-bold px-2 py-0.5 rounded-lg border ${pCfg.color} ${pCfg.bg} ${pCfg.border}`}>{pCfg.label}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* PROFILE VIEW */}
        {view === 'profile' && (
          <div className="space-y-4 slide-up">
            <div className="glass-orange rounded-2xl p-5">
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-500/25 to-orange-600/10 border border-orange-500/25 flex items-center justify-center">
                  <span className="text-2xl font-black text-orange-500">R</span>
                </div>
                <div className="flex-1">
                  <h2 className="text-lg font-black text-white">Rajan Kumar</h2>
                  <p className="text-[10px] text-orange-400 font-bold mt-0.5">TECH-001</p>
                  <div className="flex items-center gap-2 mt-1.5">
                    <span className={`text-[9px] font-bold px-2 py-0.5 rounded-lg border ${TECHNICIAN_STATUS_CONFIG.active.color} ${TECHNICIAN_STATUS_CONFIG.active.bg} ${TECHNICIAN_STATUS_CONFIG.active.border}`}>
                      Active
                    </span>
                    <span className="text-[10px] text-white/25">Since Mar 2024</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="glass rounded-2xl p-4 glass-card">
              <p className="text-[10px] font-bold text-white/25 uppercase tracking-wider mb-3">Assigned Services</p>
              <div className="flex flex-wrap gap-2">
                {['AC Service', 'Electrician'].map(s => (
                  <span key={s} className="text-[10px] bg-orange-500/8 border border-orange-500/15 text-orange-400/60 px-3 py-1 rounded-full font-semibold">{s}</span>
                ))}
              </div>
            </div>

            <div className="glass rounded-2xl p-4 glass-card space-y-3">
              <p className="text-[10px] font-bold text-white/25 uppercase tracking-wider mb-2">Stats</p>
              {[
                { icon: Star, label: 'Rating', value: '4.8 / 5.0' },
                { icon: CheckCircle, label: 'Jobs Completed', value: '127' },
                { icon: TrendingUp, label: 'Total Earnings', value: '₹84,500' },
                { icon: MapPin, label: 'City', value: 'Chennai' },
              ].map(({ icon: Icon, label, value }) => (
                <div key={label} className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5"><Icon size={13} className="text-orange-500/50" /><span className="text-[11px] text-white/35">{label}</span></div>
                  <span className="text-[11px] text-white/70 font-semibold">{value}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}

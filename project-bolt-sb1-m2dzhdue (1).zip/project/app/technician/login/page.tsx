'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowRight, ArrowLeft, Eye, EyeOff, User, Lock, Shield, Wrench } from 'lucide-react';

export default function TechnicianLoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      setError('Enter username and password');
      return;
    }
    setLoading(true);
    setError('');

    // Simulate credential check
    await new Promise(r => setTimeout(r, 1200));

    // Mock: accept known technician credentials
    const validCreds: Record<string, string> = {
      'rajan.elec': 'Rajan@123',
      'secure.cam': 'Secure@456',
      'pipe.expert': 'Pipe@789',
      'cool.air': 'Cool@101',
      'wire.pro': 'Wire@202',
    };

    if (validCreds[username] === password) {
      router.push('/technician/dashboard');
    } else {
      setError('Invalid username or password. Contact admin for access.');
      setLoading(false);
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }} className="min-h-screen bg-[#070707] flex flex-col items-center justify-center px-4 relative">
      <div className="fixed top-1/4 left-1/2 -translate-x-1/2 w-80 h-80 bg-orange-500/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="w-full max-w-sm relative z-10">
        {/* Logo */}
        <div className="text-center mb-8 slide-up">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-500 to-orange-600 glow-orange mb-4">
            <Wrench size={28} className="text-black" />
          </div>
          <h1 className="text-2xl font-black">
            <span className="text-white">VAT</span><span className="text-orange-500">TAM</span>
          </h1>
          <p className="text-white/25 text-xs mt-1.5 font-medium">Technician Login Portal</p>
        </div>

        <div className="slide-up">
          <div className="glass rounded-3xl p-6">
            <div className="flex items-center gap-2 mb-5">
              <Shield size={14} className="text-orange-500" />
              <p className="text-xs text-white/40 font-medium">Admin-created accounts only</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="text-[11px] font-semibold text-white/40 mb-1.5 block uppercase tracking-wider">Username</label>
                <div className="relative">
                  <User size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/25" />
                  <input type="text" placeholder="Enter username" value={username} onChange={e => { setUsername(e.target.value); setError(''); }}
                    className="w-full glass rounded-xl pl-10 pr-4 py-3.5 text-sm text-white placeholder-white/20 focus:outline-none focus:border-orange-500/40 transition-all" autoFocus />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-white/40 mb-1.5 block uppercase tracking-wider">Password</label>
                <div className="relative">
                  <Lock size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/25" />
                  <input type={showPassword ? 'text' : 'password'} placeholder="Enter password" value={password} onChange={e => { setPassword(e.target.value); setError(''); }}
                    className="w-full glass rounded-xl pl-10 pr-12 py-3.5 text-sm text-white placeholder-white/20 focus:outline-none focus:border-orange-500/40 transition-all" />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-white/25 hover:text-white/50">
                    {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
              </div>

              {error && <p className="text-red-400 text-xs font-medium">{error}</p>}

              <button type="submit" disabled={loading}
                className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 to-orange-600 disabled:opacity-50 text-black font-bold py-3.5 rounded-2xl transition-all duration-300 glow-orange-sm">
                {loading ? <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin" /> : <>Login <ArrowRight size={16} /></>}
              </button>
            </form>
          </div>

          <div className="glass rounded-xl p-3.5 mt-4 flex items-start gap-2.5">
            <Shield size={14} className="text-blue-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-[11px] text-white/40 leading-relaxed">Technician accounts are created by admin only. Cannot self-register?</p>
              <Link href="/login" className="text-[11px] text-orange-400 font-semibold mt-1 block">Contact admin or login as customer</Link>
            </div>
          </div>

          {/* Demo credentials hint */}
          <div className="glass rounded-xl p-3 mt-3">
            <p className="text-[10px] text-white/20 font-semibold mb-1.5">Demo Credentials:</p>
            <div className="space-y-1">
              {[
                { user: 'rajan.elec', pass: 'Rajan@123' },
                { user: 'wire.pro', pass: 'Wire@202' },
              ].map(({ user, pass }) => (
                <button key={user} onClick={() => { setUsername(user); setPassword(pass); }}
                  className="flex gap-2 text-[10px] text-white/15 hover:text-white/30 transition-colors">
                  <span className="font-mono">{user}</span><span>/</span><span className="font-mono">{pass}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Profile = {
  id: string;
  full_name: string;
  phone: string | null;
  avatar_url: string | null;
  role: 'customer' | 'provider' | 'admin';
  city: string;
  created_at: string;
};

export type Service = {
  id: string;
  name: string;
  description: string;
  icon: string;
  base_price: number;
  category: string;
  is_active: boolean;
};

export type Provider = {
  id: string;
  user_id: string;
  business_name: string;
  specializations: string[];
  rating: number;
  total_jobs: number;
  is_verified: boolean;
  is_available: boolean;
  bio: string;
  address: string;
  city: string;
  qr_slug: string | null;
};

export type Booking = {
  id: string;
  customer_id: string;
  provider_id: string | null;
  service_id: string | null;
  service_name: string;
  status: 'pending' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled';
  scheduled_date: string | null;
  scheduled_time: string;
  address: string;
  notes: string;
  total_amount: number;
  created_at: string;
};

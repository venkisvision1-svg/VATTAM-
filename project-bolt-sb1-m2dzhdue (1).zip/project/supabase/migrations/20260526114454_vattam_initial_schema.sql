/*
  # VATTAM Platform Initial Schema

  ## Tables Created
  - `profiles` - User profiles for customers and providers
  - `services` - Service categories (AC, CCTV, Plumbing, etc.)
  - `providers` - Service providers with ratings and status
  - `bookings` - Service bookings with status tracking
  - `payments` - Payment records linked to bookings
  - `reviews` - Customer reviews for completed bookings
  - `provider_qr` - QR code business profiles for providers

  ## Security
  - RLS enabled on all tables
  - Policies scoped to authenticated users
  - Admin access via role check in profiles
*/

-- Profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  phone text UNIQUE,
  avatar_url text,
  role text NOT NULL DEFAULT 'customer' CHECK (role IN ('customer', 'provider', 'admin')),
  city text DEFAULT 'Chennai',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Services table
CREATE TABLE IF NOT EXISTS services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text DEFAULT '',
  icon text DEFAULT '',
  base_price numeric NOT NULL DEFAULT 0,
  category text NOT NULL DEFAULT 'home',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE services ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active services"
  ON services FOR SELECT
  USING (is_active = true);

-- Providers table
CREATE TABLE IF NOT EXISTS providers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  business_name text NOT NULL DEFAULT '',
  specializations text[] DEFAULT '{}',
  rating numeric DEFAULT 0,
  total_jobs integer DEFAULT 0,
  is_verified boolean DEFAULT false,
  is_available boolean DEFAULT true,
  bio text DEFAULT '',
  address text DEFAULT '',
  city text DEFAULT 'Chennai',
  qr_slug text UNIQUE,
  badge_color text DEFAULT 'orange',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE providers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view verified providers"
  ON providers FOR SELECT
  USING (is_verified = true);

CREATE POLICY "Providers can update own record"
  ON providers FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Providers can insert own record"
  ON providers FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- Bookings table
CREATE TABLE IF NOT EXISTS bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  provider_id uuid REFERENCES providers(id) ON DELETE SET NULL,
  service_id uuid REFERENCES services(id) ON DELETE SET NULL,
  service_name text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'in_progress', 'completed', 'cancelled')),
  scheduled_date date,
  scheduled_time text DEFAULT '',
  address text NOT NULL DEFAULT '',
  notes text DEFAULT '',
  total_amount numeric DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Customers can view own bookings"
  ON bookings FOR SELECT
  TO authenticated
  USING (customer_id = auth.uid());

CREATE POLICY "Customers can insert bookings"
  ON bookings FOR INSERT
  TO authenticated
  WITH CHECK (customer_id = auth.uid());

CREATE POLICY "Customers can update own bookings"
  ON bookings FOR UPDATE
  TO authenticated
  USING (customer_id = auth.uid())
  WITH CHECK (customer_id = auth.uid());

-- Payments table
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid REFERENCES bookings(id) ON DELETE CASCADE,
  customer_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  amount numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'failed', 'refunded')),
  payment_method text DEFAULT 'razorpay',
  razorpay_order_id text,
  razorpay_payment_id text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Customers can view own payments"
  ON payments FOR SELECT
  TO authenticated
  USING (customer_id = auth.uid());

CREATE POLICY "Customers can insert payments"
  ON payments FOR INSERT
  TO authenticated
  WITH CHECK (customer_id = auth.uid());

-- Reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid REFERENCES bookings(id) ON DELETE CASCADE,
  customer_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  provider_id uuid REFERENCES providers(id) ON DELETE CASCADE,
  rating integer NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view reviews"
  ON reviews FOR SELECT
  USING (true);

CREATE POLICY "Customers can insert reviews"
  ON reviews FOR INSERT
  TO authenticated
  WITH CHECK (customer_id = auth.uid());

-- Seed services data
INSERT INTO services (name, description, icon, base_price, category) VALUES
  ('AC Service', 'Air conditioner cleaning, gas refill, and repair', 'wind', 499, 'appliance'),
  ('CCTV Installation', 'Professional CCTV camera installation and setup', 'camera', 1499, 'security'),
  ('Plumbing', 'Pipe repair, leakage fix, and installation', 'droplets', 399, 'home'),
  ('Electrician', 'Wiring, switchboard, and electrical repair', 'zap', 349, 'home'),
  ('Refrigerator Repair', 'Fridge cooling, compressor, and door seal repair', 'thermometer', 599, 'appliance'),
  ('Washing Machine Service', 'Drum cleaning, motor repair, and servicing', 'circle', 449, 'appliance')
ON CONFLICT DO NOTHING;

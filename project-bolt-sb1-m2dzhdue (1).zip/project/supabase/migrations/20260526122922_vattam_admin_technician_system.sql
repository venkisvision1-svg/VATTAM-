/*
  # VATTAM Admin Control System - Technician Management

  ## Changes
  1. New Tables
    - `technicians` - Admin-created technician accounts with username/password
    - `technician_earnings` - Earnings tracking per technician
    - `upi_payments` - UPI payment records with QR and transaction IDs

  2. Modified Tables
    - `bookings` - Added `technician_id` column, `work_photo_url`, `technician_status`

  ## Security
  - RLS enabled on all new tables
  - Technicians can only read/update their own data
  - Admin has broader access via role check
*/

-- Technicians table (admin-created only)
CREATE TABLE IF NOT EXISTS technicians (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tech_id text UNIQUE NOT NULL,
  username text UNIQUE NOT NULL,
  password_hash text NOT NULL,
  full_name text NOT NULL DEFAULT '',
  phone text DEFAULT '',
  assigned_category text NOT NULL DEFAULT 'home',
  assigned_services text[] DEFAULT '{}',
  city text DEFAULT 'Chennai',
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'blocked', 'removed')),
  rating numeric DEFAULT 0,
  total_jobs integer DEFAULT 0,
  total_earnings numeric DEFAULT 0,
  is_available boolean DEFAULT true,
  created_by uuid REFERENCES profiles(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE technicians ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view all technicians"
  ON technicians FOR SELECT
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

CREATE POLICY "Technicians can view own record"
  ON technicians FOR SELECT
  TO authenticated
  USING (username = (SELECT raw_user_meta_data->>'username' FROM auth.users WHERE id = auth.uid()));

CREATE POLICY "Admins can insert technicians"
  ON technicians FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

CREATE POLICY "Admins can update technicians"
  ON technicians FOR UPDATE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

-- Add technician_id to bookings
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'bookings' AND column_name = 'technician_id'
  ) THEN
    ALTER TABLE bookings ADD COLUMN technician_id uuid REFERENCES technicians(id);
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'bookings' AND column_name = 'work_photo_url'
  ) THEN
    ALTER TABLE bookings ADD COLUMN work_photo_url text;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'bookings' AND column_name = 'technician_status'
  ) THEN
    ALTER TABLE bookings ADD COLUMN technician_status text DEFAULT 'pending' CHECK (technician_status IN ('pending', 'accepted', 'rejected', 'in_progress', 'completed'));
  END IF;
END $$;

-- UPI Payments table
CREATE TABLE IF NOT EXISTS upi_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid REFERENCES bookings(id) ON DELETE CASCADE,
  customer_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  amount numeric NOT NULL DEFAULT 0,
  upi_id text DEFAULT '',
  transaction_id text DEFAULT '',
  qr_code_url text DEFAULT '',
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'success', 'failed', 'refunded')),
  payment_method text DEFAULT 'upi' CHECK (payment_method IN ('upi', 'qr', 'link')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE upi_payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Customers can view own payments"
  ON upi_payments FOR SELECT
  TO authenticated
  USING (customer_id = auth.uid());

CREATE POLICY "Admins can view all payments"
  ON upi_payments FOR SELECT
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

CREATE POLICY "Customers can insert payments"
  ON upi_payments FOR INSERT
  TO authenticated
  WITH CHECK (customer_id = auth.uid());

-- Technician Earnings table
CREATE TABLE IF NOT EXISTS technician_earnings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  technician_id uuid REFERENCES technicians(id) ON DELETE CASCADE,
  booking_id uuid REFERENCES bookings(id) ON DELETE CASCADE,
  amount numeric NOT NULL DEFAULT 0,
  platform_fee numeric NOT NULL DEFAULT 0,
  net_amount numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'held')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE technician_earnings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Technicians can view own earnings"
  ON technician_earnings FOR SELECT
  TO authenticated
  USING (technician_id IN (SELECT id FROM technicians WHERE username = (SELECT raw_user_meta_data->>'username' FROM auth.users WHERE id = auth.uid())));

CREATE POLICY "Admins can view all earnings"
  ON technician_earnings FOR SELECT
  TO authenticated
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_technicians_status ON technicians(status);
CREATE INDEX IF NOT EXISTS idx_technicians_category ON technicians(assigned_category);
CREATE INDEX IF NOT EXISTS idx_bookings_technician_id ON bookings(technician_id);
CREATE INDEX IF NOT EXISTS idx_upi_payments_booking_id ON upi_payments(booking_id);
CREATE INDEX IF NOT EXISTS idx_upi_payments_status ON upi_payments(status);
